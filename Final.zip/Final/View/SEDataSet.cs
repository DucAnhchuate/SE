﻿namespace View
{


    partial class SEDataSet
    {
    }
}

namespace View.SEDataSetTableAdapters {
    
    
    public partial class ReceiptInfoTableAdapter {
    }
}
