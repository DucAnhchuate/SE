﻿namespace View
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.panel_top = new System.Windows.Forms.Panel();
            this.labelUser = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.Order = new System.Windows.Forms.TabPage();
            this.body2 = new System.Windows.Forms.Panel();
            this.Receipt = new System.Windows.Forms.TabPage();
            this.body1 = new System.Windows.Forms.Panel();
            this.tab = new System.Windows.Forms.TabControl();
            this.panel_top.SuspendLayout();
            this.Order.SuspendLayout();
            this.Receipt.SuspendLayout();
            this.tab.SuspendLayout();
            this.SuspendLayout();
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // panel_top
            // 
            this.panel_top.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel_top.Controls.Add(this.labelUser);
            this.panel_top.Controls.Add(this.label1);
            this.panel_top.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_top.Location = new System.Drawing.Point(0, 0);
            this.panel_top.Name = "panel_top";
            this.panel_top.Size = new System.Drawing.Size(1588, 26);
            this.panel_top.TabIndex = 1;
            // 
            // labelUser
            // 
            this.labelUser.AutoSize = true;
            this.labelUser.Location = new System.Drawing.Point(62, 6);
            this.labelUser.Name = "labelUser";
            this.labelUser.Size = new System.Drawing.Size(0, 13);
            this.labelUser.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Manager:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.Name = "contextMenuStrip2";
            this.contextMenuStrip2.Size = new System.Drawing.Size(61, 4);
            // 
            // Order
            // 
            this.Order.Controls.Add(this.body2);
            this.Order.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Order.Location = new System.Drawing.Point(4, 22);
            this.Order.Name = "Order";
            this.Order.Padding = new System.Windows.Forms.Padding(3);
            this.Order.Size = new System.Drawing.Size(1580, 457);
            this.Order.TabIndex = 1;
            this.Order.Text = "ORDER";
            this.Order.UseVisualStyleBackColor = true;
            // 
            // body2
            // 
            this.body2.BackColor = System.Drawing.Color.RosyBrown;
            this.body2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.body2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.body2.Location = new System.Drawing.Point(3, 3);
            this.body2.Name = "body2";
            this.body2.Size = new System.Drawing.Size(1574, 451);
            this.body2.TabIndex = 0;
            // 
            // Receipt
            // 
            this.Receipt.BackColor = System.Drawing.Color.Transparent;
            this.Receipt.Controls.Add(this.body1);
            this.Receipt.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Receipt.ForeColor = System.Drawing.Color.Black;
            this.Receipt.Location = new System.Drawing.Point(4, 22);
            this.Receipt.Name = "Receipt";
            this.Receipt.Padding = new System.Windows.Forms.Padding(3);
            this.Receipt.Size = new System.Drawing.Size(1580, 457);
            this.Receipt.TabIndex = 0;
            this.Receipt.Text = "RECEIPT";
            // 
            // body1
            // 
            this.body1.BackColor = System.Drawing.Color.RosyBrown;
            this.body1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.body1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.body1.Location = new System.Drawing.Point(3, 3);
            this.body1.Name = "body1";
            this.body1.Size = new System.Drawing.Size(1574, 451);
            this.body1.TabIndex = 0;
            // 
            // tab
            // 
            this.tab.Controls.Add(this.Receipt);
            this.tab.Controls.Add(this.Order);
            this.tab.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tab.Location = new System.Drawing.Point(0, 32);
            this.tab.Name = "tab";
            this.tab.SelectedIndex = 0;
            this.tab.Size = new System.Drawing.Size(1588, 483);
            this.tab.TabIndex = 2;
            this.tab.SelectedIndexChanged += new System.EventHandler(this.tab_SelectedIndexChanged);
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1588, 512);
            this.Controls.Add(this.tab);
            this.Controls.Add(this.panel_top);
            this.Name = "Home";
            this.Text = "Home";
            this.Load += new System.EventHandler(this.Home_Load);
            this.panel_top.ResumeLayout(false);
            this.panel_top.PerformLayout();
            this.Order.ResumeLayout(false);
            this.Receipt.ResumeLayout(false);
            this.tab.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.Panel panel_top;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelUser;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private System.Windows.Forms.TabPage Order;
        private System.Windows.Forms.Panel body2;
        private System.Windows.Forms.TabPage Receipt;
        private System.Windows.Forms.Panel body1;
        private System.Windows.Forms.TabControl tab;
    }
}

