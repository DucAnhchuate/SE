﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BUS;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace View
{
    public partial class fReceipt : Form
    {
        BUS_Receipt Receipt = new BUS_Receipt("", null, 0, null, null);

        BUS_ReceiptInfo Info = new BUS_ReceiptInfo(null, null, null, 0, 0, 0);

        BUS_Item Item = new BUS_Item(null, null, null);
    
        BUS_Supplier Supplier = new BUS_Supplier(null, null, null, null, null, null);

        BUS_User User = new BUS_User(null, null, null, null);

        string flag = null;

        string user = null;
        public fReceipt()
        {
            InitializeComponent();
        }
        public fReceipt(string user): this()
        {
            this.user = user;
        }
        private void Receipt_Load(object sender, EventArgs e)
        {
            Form_Load();

            displayPName();

            displaySup();

            cbStt.Text = "False";

            date.CustomFormat = "yyyy-MM-dd";

            txtRID.ReadOnly = true;

            txtPID.ReadOnly = true;

            cbSup.Enabled = false;

            txtPID.Clear();

            txtUser.ReadOnly = true;

            User = new BUS_User(null, null, user, null);

            txtUser.Text = User.getID();

            grd1.AllowUserToAddRows = false;

            grd2.AllowUserToAddRows = false;

            this.cbStt.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;

            this.cbPName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;

            this.cbSup.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;

        }
        public void Form_Load()
        {
            showGrd1();

            showGrd2();

            txtPID.Clear();

            date.Enabled = true;

            cbStt.Enabled = true;

            cbStt.Text = "False";

            enableButton(false);

            btAdd.Enabled = true;

            txtRID.Text = Receipt.CreateID();

            groupBox2.Enabled = true;

            clearText();

        }
        public void displaySup()
        {
            cbSup.DataSource = Supplier.selectQuery();

            cbSup.DisplayMember = "DisplayName";

            cbSup.ValueMember = "ID";
        }
        public void displayPName()
        {
            cbPName.DataSource = Item.selectQuery();

            cbPName.DisplayMember = "DisplayName";

            cbPName.ValueMember = "DisplayName";
        }
        public void clearText()
        {
            txtPID.Clear();

            txtQuan.Clear();

            txtOP.Clear();

            txtRP.Clear();

        }
        public void enableButton(bool b)
        {
            btAdd.Enabled = b;

            btCancel.Enabled = b;

            btDelete.Enabled = b;

            btSave.Enabled = b;
        }
        public void showGrd1()
        {
            grd1.DataSource = Receipt.selectQuery();
        }

        public void showGrd2()
        {
            Info = new BUS_ReceiptInfo(null, null, txtRID.Text, 0, 0, 0);

            grd2.DataSource = Info.selectQuery();
        }
        public void showGrd2(string txtRID)
        {
            Info = new BUS_ReceiptInfo(null, null, txtRID, 0, 0, 0);

            grd2.DataSource = Info.selectQuery();

        }

        private void btAdd_Click(object sender, EventArgs e)
        {
            string InfoID = Info.CreateID();

            string RID = txtRID.Text;

            string Date = date.Text.ToString();

            string User = txtUser.Text;

            string Status = cbStt.Text;

            Receipt = new BUS_Receipt(RID, null, 0, null, null);


            if (!Receipt.checkReceipt())
            {
                BUS_Receipt Receipt = new BUS_Receipt(RID, Date, 0, Status, User);

                Receipt.addQuery();

                //check Total = null

                Receipt.updateTotal();

                if (Receipt.TotalEmpty())
                {
                    Receipt = new BUS_Receipt(RID, Date, 0, Status, User);

                    Receipt.updateQuery();
                }

            }

            string PID = txtPID.Text;

            string Quantity = txtQuan.Text;

            string RP = txtRP.Text;

            string PName = cbPName.Text;

            string OP = txtOP.Text;

            if (PID != "" && Quantity != "" && RP != "" && OP != "" && PName != "")
            {
                Info = new BUS_ReceiptInfo(InfoID, PID, RID, Int32.Parse(Quantity), float.Parse(RP), float.Parse(OP));

                Info.addQuery();

                BUS_Receipt Receipt = new BUS_Receipt(RID, Date, 0, Status, User);

                Receipt.updateTotal();

                //check Total = null

                clearText();

                showGrd1();

                showGrd2();
            }
            else
            {
                MessageBox.Show("Please complete all information");
            }
            showGrd1();

            showGrd2();
        }

        private void grd1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtRID.Text = grd1.CurrentRow.Cells[0].Value.ToString();

            showGrd2();

            clearText();

            enableButton(false);

            btAdd.Enabled = true;

            btDelete.Enabled = true;

            date.Enabled = true;

            cbStt.Enabled = true;

            flag = "ReceiptClick";

            date.Text = grd1.CurrentRow.Cells[1].Value.ToString();

        }

        private void grd2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtPID.Text = grd2.CurrentRow.Cells[1].Value.ToString();

            txtQuan.Text = grd2.CurrentRow.Cells[3].Value.ToString();

            txtRP.Text = grd2.CurrentRow.Cells[4].Value.ToString();

            txtOP.Text = grd2.CurrentRow.Cells[5].Value.ToString();

            enableButton(true);

            groupBox2.Enabled = true;

            btAdd.Enabled = false;

            date.Enabled = false;

            cbStt.Enabled = false;

            flag = "InfoClick";
        }

        private void btSave_Click(object sender, EventArgs e)
        {

            string RID = txtRID.Text;

            string Date = date.Text.ToString();

            string User = txtUser.Text;

            string Status = cbStt.Text;

            string PID = txtPID.Text;

            string Quantity = txtQuan.Text;

            string RP = txtRP.Text;

            string PName = cbPName.Text;

            string OP = txtOP.Text;

            if (flag.Equals("InfoClick"))
            {
                if (PID != "" && Quantity != "" && RP != "" && OP != "" && PName != "")
                {
                    Info = new BUS_ReceiptInfo(grd2.CurrentRow.Cells[0].Value.ToString(), PID, RID, Int32.Parse(Quantity), float.Parse(RP), float.Parse(OP));

                    Info.updateQuery();

                    BUS_Receipt Receipt = new BUS_Receipt(RID, Date, 0, Status, User);

                    Receipt.updateTotal();

                    clearText();

                    showGrd1();

                    showGrd2();

                    groupBox2.Enabled = true;
                }
                else
                {
                    MessageBox.Show("Please complete all information");
                }
            }
            else if (flag.Equals("DateChange") || flag.Equals("SttChange")) 
            {
       
                Receipt = new BUS_Receipt(grd1.CurrentRow.Cells[0].Value.ToString(), Date, 0,  Status, User);

                Receipt.updateQuery();

                Receipt.updateTotal();

                clearText();

                showGrd1();

                showGrd2();

                groupBox2.Enabled = true;
            }    

        }

        private void date_ValueChanged(object sender, EventArgs e)
        {
                enableButton(false);

                btSave.Enabled = true;

                btAdd.Enabled = true;

                flag = "DateChange";

                groupBox2.Enabled = true;
        }

        private void btDelete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you want to delete?", "", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                if (flag.Equals("InfoClick"))
                {
                    Info = new BUS_ReceiptInfo(grd2.CurrentRow.Cells[0].Value.ToString(), null, null, 0, 0, 0);

                    Info.deleteQuery();

                    BUS_Receipt Receipt = new BUS_Receipt(txtRID.Text, null, 0, null, null);

                    Receipt.updateTotal();

                    //check Total = null

                    string RID = txtRID.Text;

                    string Date = date.Text.ToString();

                    string User = txtUser.Text;

                    string Status = cbStt.Text;

                    if (Receipt.TotalEmpty())
                    {
                        Receipt = new BUS_Receipt(RID, Date, 0, Status, User);

                        Receipt.updateQuery();
                    }

                    Form_Load();
                }
                else if (flag.Equals("ReceiptClick"))
                {
                    Receipt = new BUS_Receipt(grd1.CurrentRow.Cells[0].Value.ToString(), null, 0,  null, null);

                    Receipt.deleteQuery();

                    Form_Load();
                }
            }

        }

        private void cbStt_SelectedIndexChanged(object sender, EventArgs e)
        {
            enableButton(false);

            btSave.Enabled = true;

            flag = "SttChange";

            groupBox2.Enabled = false;
        }

        private void cbStt_ValueMemberChanged(object sender, EventArgs e)
        {
            enableButton(false);

            btSave.Enabled = true;

            flag = "SttChange";

            groupBox2.Enabled = false;

        }

        private void btNew_Click(object sender, EventArgs e)
        {
            Form_Load();
        }
        private void cbPName_SelectionChangeCommitted(object sender, EventArgs e)
        {
            cbSup.Enabled = true;

            txtPID.Clear();
        }

        private void btCancel_Click(object sender, EventArgs e)
        {
            Form_Load();
        }

        private void cbSup_SelectionChangeCommitted(object sender, EventArgs e)
        {
            txtPID.Clear();

            Supplier = new BUS_Supplier(null, cbSup.Text, null, null, null ,null);

            string IDSup = Supplier.getID();

            Item = new BUS_Item(null, cbPName.Text, IDSup);

            if (Item.getID() != null)
            {
                txtPID.Text = Item.getID();
            }
            else
            {
                MessageBox.Show("This supplier does not provide this item");
                Form_Load();
            }
        }
    }
}
