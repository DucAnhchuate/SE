﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace View
{
    public partial class Home : Form
    {
        private string buffer;
        public Home()
        {
            InitializeComponent();
        }
        private void Home_Load(object sender, EventArgs e)
        {                        
            labelUser.Text = buffer;

            OpenFormChild(new fReceipt(buffer), body1);

        }

        public Home(string user): this()
        {
            buffer = user;
        }


        public void enableGrp(GroupBox grp, bool b)
        {
            grp.Enabled = b;
        }



        private Form currentFormChild;
        private void OpenFormChild(Form childForm, Panel body)
        {
            if (currentFormChild != null)
            {
                currentFormChild.Close();
            }
            currentFormChild = childForm;

            childForm.TopLevel = false;

            childForm.FormBorderStyle = FormBorderStyle.None;

            childForm.Dock = DockStyle.Fill;

            body.Controls.Add(childForm);

            body.Tag = childForm;

            childForm.BringToFront();

            childForm.Show();
        }

        private void tab_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tab.SelectedIndex == 0)
            {
                OpenFormChild(new fReceipt(buffer), body1);
            }
            else if(tab.SelectedIndex == 1) 
            {
                //OpenFormChild(new fOrder(), body2);

            }
        }
    }
}
