﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class DTO_Supplier
    {
        private string ID, DisplayName, Address, Phone, Email, MoreInfo;

        public string getID
        {
            get { return ID; }

            set { ID = value; }
        }

        public string getDisplayName
        {
            get { return DisplayName; }

            set { DisplayName = value; }
        }

        public string getAddress
        {
            get { return Address; }

            set { Address = value; }
        }

        public string getPhone
        {
            get { return Phone; }

            set { Phone = value; }
        }

        public string getEmail
        {
            get { return Email; }

            set { Email = value; }
        }

        public string getMoreInfo
        {
            get { return MoreInfo; }
            
            set { MoreInfo = value; }
        }

        public DTO_Supplier(string ID, string DisplayName, string Address, string Phone, string Email, string MoreInfo) 
        {
            this.ID = ID;

            this.DisplayName = DisplayName;

            this.Address = Address;

            this.Phone = Phone;

            this.Email = Email;

            this.MoreInfo = MoreInfo;
        }
    }
}
