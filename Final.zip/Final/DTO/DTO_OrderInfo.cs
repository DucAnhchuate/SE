﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class DTO_OrderInfo
    {
        private string ID, IDItem, IDReceiptInfo, IDCustomer, IDOrder;
        private int OrderQuantity;

        public string getID
        {
            set { ID = value; }

            get { return ID; }
        }

        public string getIDItem
        {
            set { IDItem = value; }

            get { return IDItem; }
        }

        public string getIDReceiptInfor
        {
            set { IDReceiptInfo = value; }

            get { return IDReceiptInfo; }
        }

        public string getIDCustomer
        {
            get { return IDCustomer; }

            set { IDCustomer = value; }
        }

        public string getIDOrder
        {
            get { return IDOrder; }

            set { IDOrder = value; }
        }

        public DTO_OrderInfo(string ID, string IDItem, string IDReceiptInfo, string IDCustomer, string IDOrder, int OrderQuantity)
        {
            this.ID = ID;

            this.IDItem = IDItem;

            this.IDReceiptInfo = IDReceiptInfo;

            this.IDCustomer = IDCustomer;

            this.IDOrder = IDOrder;

            this.OrderQuantity = OrderQuantity;
        }
    }
}
