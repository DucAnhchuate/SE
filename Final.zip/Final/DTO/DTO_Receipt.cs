﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class DTO_Receipt
    {
        private string ID, DateReceipt, Status, UserID;

        private float Total;

        public string getID
        {
            set { this.ID = value; }

            get { return this.ID; }
        }

        public string getDateReceipt
        {
            get { return this.DateReceipt; }
            
            set { this.DateReceipt = value; }
        }
        public string getStatus
        {
            get { return this.Status; }
            set { this.Status = value; }
        }
        public string getUserID
        {
            get { return this.UserID; }
            set { this.UserID = value; }
        }
        public float getTotal
        {
            get { return this.Total; }
            set { this.Total = value; }
        }
        public DTO_Receipt(string ID, string DateReceipt, float Total, string Status, string UserID)
        {
            this.ID = ID;

            this.DateReceipt = DateReceipt;

            this.Total = Total;

            this.Status = Status;

            this.UserID = UserID;

        }
    }
}
