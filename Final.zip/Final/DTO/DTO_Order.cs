﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class DTO_Order
    {
        private string ID, DateOrder;

        public string getID
        {
            set { this.ID = value; }

            get { return this.ID; }
        }

        public string getDateOrder
        {
            get { return this.DateOrder; }

            set { this.DateOrder = value; }
        }
        public DTO_Order(string ID, string DateOrder)
        {
            this.ID = ID;

            this.DateOrder = DateOrder;
        }
    }
}
