﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;

namespace BUS
{
    public class BUS_User
    {
        DAL_User User;

        public BUS_User(string ID, string DisplayName, string Username, string Password)
        {
            User = new DAL_User(ID, DisplayName, Username, Password);
        }

        public void addQuery()
        {
            User.addQuery();
        }
        public void updateQuery()
        {
            User.updateQuery();
        }
        public void deleteQuery()
        {
            User.deleteQuery();
        }
        public DataTable selectQuery()
        {
            return User.selectQuery();
        }
        public string CreateID()
        {
            DataTable tb = User.getUserDesc(); //User01
            if (tb.Rows.Count > 0)
            {
                string res = tb.Rows[0][0].ToString();
                int stt = int.Parse(res.Substring(4, 2)) + 1;
                if (stt < 10)
                    res = "User0" + stt.ToString();
                else if (stt < 100)
                    res = "User" + stt.ToString();
                return res;
            }
            else
            {
                return "User01";
            }
        }
        public bool checkLogin()
        {
            return User.Login().Rows.Count > 0;
        }
        public string getID()
        {
            return User.getID().Rows[0][0].ToString();
        }
    }
}

