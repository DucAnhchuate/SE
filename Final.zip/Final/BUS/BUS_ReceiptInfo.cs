﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;

namespace BUS
{
    public class BUS_ReceiptInfo
    {
        DAL_ReceiptInfo ReceiptInfo;

        public BUS_ReceiptInfo(string ID, string IDItem, string IDReceipt, int ReceipQuantity, float Receipt_price, float Order_Price)
        {
            ReceiptInfo = new DAL_ReceiptInfo(ID, IDItem, IDReceipt, ReceipQuantity, Receipt_price, Order_Price);
        }

        public void addQuery()
        {
            ReceiptInfo.addQuery();
        }
        public void updateQuery()
        {
            ReceiptInfo.updateQuery();
        }
        public void deleteQuery()
        {
            ReceiptInfo.deleteQuery();
        }
        public DataTable selectQuery()
        {
            return ReceiptInfo.selectQuery();
        }
        public string CreateID()
        {
            DataTable tb = ReceiptInfo.getReceiptInfoDesc(); //RI00001
            if (tb.Rows.Count > 0)
            {
                string res = tb.Rows[0][0].ToString();
                int stt = int.Parse(res.Substring(2, 5)) + 1;
                if (stt < 10)
                    res = "RI0000" + stt.ToString();
                else if (stt < 100)
                    res = "RI000" + stt.ToString();
                else if (stt < 1000)
                    res = "RI00" + stt.ToString();
                else if (stt < 10000)
                    res = "RI0" + stt.ToString();
                return res;
            }
            else
            {
                return "RI00001";
            }
        }
    }
}
