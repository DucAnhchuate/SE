﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;

namespace BUS
{
    public class BUS_Item
    {
        DAL_Item Item;

        public BUS_Item(string ID, string DisplayName, string Supplier)
        {
            Item = new DAL_Item(ID, DisplayName, Supplier);
        }

        public void addQuery()
        {
            Item.addQuery();
        }
        public void updateQuery()
        {
            Item.updateQuery();
        }
        public void deleteQuery()
        {
            Item.deleteQuery();
        }
        public DataTable selectQuery()
        {
            return Item.selectQuery();
        }
        public string CreateID()
        {
            DataTable tb = Item.getItemDesc(); //Item00001
            if (tb.Rows.Count > 0)
            {
                string res = tb.Rows[0][0].ToString();
                int stt = int.Parse(res.Substring(4, 5)) + 1;
                if (stt < 10)
                    res = "Item0000" + stt.ToString();
                else if (stt < 100)
                    res = "Item000" + stt.ToString();
                else if (stt < 1000)
                    res = "Item00" + stt.ToString();
                else if (stt < 10000)
                    res = "Item0" + stt.ToString();
                return res;
            }
            else
            {
                return "Item00001";
            }
        }
        public string getID()
        {
            if (Item.getID().Rows.Count > 0)
            {
                return Item.getID().Rows[0][0].ToString();

            }
            else 
            {
                return null; 
            }
        }
    }
}
