﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO;

namespace DAL
{
    public class DAL_Item
    {
        private string ID, DisplayName, IDSupplier;

        private DTO_Item Item;

        public DAL_Item(string ID, string DisplayName, string IDSupplier)
        {
            Item = new DTO_Item(ID, DisplayName, IDSupplier);
        }
        public void addQuery()
        {
            string query = "insert into Item values (N'" + Item.getID + "',N'" + Item.getDisplayName + "',N'" + Item.getIDSupplier + "')";

            Connection.actionQuery(query);
        }
        public void updateQuery() { }

        public void deleteQuery() { }

        public DataTable selectQuery()
        {
            string s = "select DisplayName from Item group by DisplayName";

            return Connection.selectQuery(s);
        }

        public DataTable getItemDesc()
        {
            string s = "select top 1 ID from Item order by ID desc";

            return Connection.selectQuery(s);
        }
        public DataTable getID()
        {
            string s = "select ID from Item where DisplayName like '" + Item.getDisplayName + "' and IDsupplier like '" + Item.getIDSupplier + "'";

            return Connection.selectQuery(s);
        }
    }
}
