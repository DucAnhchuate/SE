﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO;

namespace DAL
{
    public class DAL_Receipt
    {
        private DTO_Receipt Receipt;

        private string ID, DateReceipt, Status, UserID;

        private float Total;

        public DAL_Receipt(string ID, string DateReceipt, float Total, string Status, string UserID)
        {
            Receipt = new DTO_Receipt(ID, DateReceipt, Total, Status, UserID);
        }

        public void addQuery()
        {
            string query = "insert into Receipt values (N'" + Receipt.getID + "','" + Receipt.getDateReceipt + "'," + Receipt.getTotal + ",N'" + Receipt.getStatus + "',N'" + Receipt.getUserID + "')";

            Connection.actionQuery(query);
        }
        public void updateQuery() 
        {
            string query = "update Receipt set DateReceipt = '" + Receipt.getDateReceipt + "',Status = '" + Receipt.getStatus + "', UserID = '" + Receipt.getUserID +"', Total = " + Receipt.getTotal + " where ID like '" + Receipt.getID + "'";

            Connection.actionQuery(query);
        }

        public void deleteQuery() {


            string query = "delete from ReceiptInfo where IDReceipt like '" + Receipt.getID + "'";

            Connection.actionQuery(query);

            query = "delete from Receipt where ID like '" + Receipt.getID + "'";

            Connection.actionQuery(query);

        }

        public DataTable selectQuery()
        {
            string s = "select * from Receipt";

            return Connection.selectQuery(s);
        }

        public DataTable getReceiptDesc()
        {
            string s = "select top 1 ID from Receipt order by ID desc";

            return Connection.selectQuery(s);
        }

        public DataTable checkReceipt()
        {
            string s = "select * from Receipt  where ID like '" + Receipt.getID + "'";

            return Connection.selectQuery(s);
        }

        public void updateTotal()
        {
            string s = "update Receipt set Total = (select sum(Receipt_Price) from ReceiptInfo where IDReceipt like '" + Receipt.getID + "') where ID like '" + Receipt.getID + "'";

            Connection.actionQuery(s);
        }
        public DataTable TotalEmpty()
        {
            string s = "select Total from Receipt where ID like '" + Receipt.getTotal + "'";

            return Connection.selectQuery(s);

        }
    } 
}
