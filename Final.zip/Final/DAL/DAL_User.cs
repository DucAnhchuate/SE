﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO;

namespace DAL
{
    public class DAL_User
    {
        private DTO_User User;

        private string ID, DisplayName, Username, Password;

        public DAL_User(string ID, string DisplayName, string Username, string Password) 
        {
            User = new DTO_User(ID, DisplayName, Username, Password);
        }
        public void addQuery()
        {
            string query = "insert into Users values (N'" + User.getID + "',N'" + User.getDisplayName

                + "',N'" + User.getUserName + "',N'" + User.getPassword + "')";

            Connection.actionQuery(query);
        }

        public void updateQuery() { }

        public void deleteQuery() { }

        public DataTable selectQuery() 
        {
            string s = "select * from Users";

            return Connection.selectQuery(s);
        }

        public DataTable getUserDesc() 
        {
            string s = "select top 1 ID from Users order by ID desc";

            return Connection.selectQuery(s);
        }
        public DataTable getID()
        {
            string s = "select * from Users where Username like '" + User.getUserName + "'";

            return Connection.selectQuery(s);
        }
        public DataTable Login()
        {
            string s = "select * from Users where Username like '" + User.getUserName + "' and user_Password like '" + User.getPassword + "'";

            return Connection.selectQuery(s);
        }
    }
}
