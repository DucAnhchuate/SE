﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO;

namespace DAL
{
    public class DAL_ReceiptInfo
    {
        private DTO_ReceiptInfo ReceiptInfo;

        private string ID, IDItem, IDReceipt;

        private int ReceipQuantity;

        private float Receipt_Price, Order_Price;

        public DAL_ReceiptInfo(string ID, string IDItem, string IDReceipt, int ReceipQuantity, float Receipt_price, float Order_Price)
        {
            ReceiptInfo = new DTO_ReceiptInfo(ID, IDItem, IDReceipt, ReceipQuantity, Receipt_price, Order_Price);
        }

        public void addQuery()
        {
            string query = "insert into ReceiptInfo values (N'" + ReceiptInfo.getID + "',N'" + ReceiptInfo.getIDItem

                    + "',N'" + ReceiptInfo.getIDReceipt + "'," + ReceiptInfo.getReceiptQuantity + "," + ReceiptInfo.getReceipt_Price + "," + ReceiptInfo.getOrder_Price + ")";

            Connection.actionQuery(query);

            query = "update Receipt set Total = (select sum(Receipt_Price) from ReceiptInfo where IDReceipt like '" + ReceiptInfo.getIDReceipt + "') where ID like '" + ReceiptInfo.getIDReceipt + "'";

            Connection.actionQuery(query);

        }

        public void updateQuery() 
        {
            string query = "Update ReceiptInfo set IDitem = '" + ReceiptInfo.getIDItem + "', IDReceipt = '" + ReceiptInfo.getIDReceipt + "', Receipt_Quantity = " + ReceiptInfo.getReceiptQuantity +
                ", Receipt_Price =" + ReceiptInfo.getReceipt_Price + ", Order_Price = " + ReceiptInfo.getOrder_Price + " where ID like '" + ReceiptInfo.getID + "'";

            Connection.actionQuery(query);

            query = "update Receipt set Total = (select sum(Receipt_Price) from ReceiptInfo where IDReceipt like '" + ReceiptInfo.getIDReceipt + "') where ID like '" + ReceiptInfo.getIDReceipt + "'";

            Connection.actionQuery(query);
        }

        public void deleteQuery() 
        {

            string query = "delete from ReceiptInfo where ID like '" + ReceiptInfo.getID + "'";

            Connection.actionQuery(query);
        }
        public DataTable selectQuery()
        {
            string s = "select * from ReceiptInfo where IDReceipt like '" + ReceiptInfo.getIDReceipt +"'";

            return Connection.selectQuery(s);
        }

        public DataTable getReceiptInfoDesc()
        {
            string s = "select top 1 ID from ReceiptInfo order by ID desc";

            return Connection.selectQuery(s);
        }
    }
}
