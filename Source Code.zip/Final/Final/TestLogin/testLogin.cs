﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using BUS;

namespace TestLogin
{
    [TestClass]
    public class testLogin
    {
        private TestContext testContext;
        public TestContext TestContext
        {

            get { return testContext; }
            set { testContext = value; }

        }

        [TestMethod]
        [DataSource("Microsoft.VisualStudio.TestTools.DataSource.CSV",
         @"|DataDirectory|\Data\AccLogin.csv", "AccLogin#csv", DataAccessMethod.Sequential)]
        public void TestMethod1()
        {
            string Username, Password;
            Username = TestContext.DataRow[0].ToString();
            Password = TestContext.DataRow[1].ToString();

            BUS_Staff n = new BUS_Staff("", "", Username, Password);

            bool res = n.checkLogin();
            Assert.AreEqual(res, true);

        }
    }
}
