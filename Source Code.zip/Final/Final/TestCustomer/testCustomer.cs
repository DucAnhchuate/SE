﻿using BUS;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace TestCustomer
{
    [TestClass]
    public class testCustomer
    {
        private TestContext testContext;
        public TestContext TestContext
        {

            get { return testContext; }
            set { testContext = value; }

        }
        [TestMethod]
        [DataSource("Microsoft.VisualStudio.TestTools.DataSource.CSV",
         @"|DataDirectory|\Data\Customer.csv", "Customer#csv", DataAccessMethod.Sequential)]
        public void TestMethod1()
        {
            string Phone;
            
            Phone = TestContext.DataRow[0].ToString();

            BUS_Customer n = new BUS_Customer("","","",Phone,"","");

            bool res = n.checkPhone();

            Assert.AreEqual(res, true);
        }
    }
}
