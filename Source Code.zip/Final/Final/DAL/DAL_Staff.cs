﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO;

namespace DAL
{
    public class DAL_Staff
    {
        private DTO_Staff User;


        public DAL_Staff(string ID, string DisplayName, string Username, string Password) 
        {
            User = new DTO_Staff(ID, DisplayName, Username, Password);
        }
        public void addQuery()
        {
            string query = "insert into Staff values (N'" + User.getID + "',N'" + User.getDisplayName

                + "',N'" + User.getUserName + "',N'" + User.getPassword + "')";

            Connection.actionQuery(query);
        }

        public void updateQuery()
        {
            string s = "Update Staff set user_Password = '" + User.getPassword + "' where Username like '" + User.getUserName + "'";

            Connection.actionQuery(s);
        }

        public void deleteQuery() 
        {
            string s = "Delete from Staff  where ID like '" + User.getID + "'";

            Connection.actionQuery(s);
        }

        public DataTable selectQuery() 
        {
            string s = "select * from Staff";

            return Connection.selectQuery(s);
        }

        public DataTable getUserDesc() 
        {
            string s = "select top 1 ID from Staff order by ID desc";

            return Connection.selectQuery(s);
        }
        public DataTable getID()
        {
            string s = "select * from Staff where Username like '" + User.getUserName + "'";

            return Connection.selectQuery(s);
        }
        public DataTable Login()
        {
            string s = "select * from Staff where Username like '" + User.getUserName + "' and user_Password like '" + User.getPassword + "'";

            return Connection.selectQuery(s);
        }
    }
}
