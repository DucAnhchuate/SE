﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Data;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using DTO;

namespace DAL
{
    public class DAL_Inventory
    {


        private DTO_Inventory Inventory;

        public DAL_Inventory(string DateStart, string DateEnd, string IDITem, int Order, int Receipt, int inventory)
        {
            Inventory = new DTO_Inventory(DateStart, DateEnd, IDITem, Order, Receipt, inventory);
        }
        public DataTable SelectInventory_Detail()
        {
            string s =("select DisplayName as MobilePhone, sum(isnull(Nhapkho,0)) as Receipt, sum(isnull(Xuatkho,0)) as 'Order'," +
                " sum(isNull(Nhapkho,0) - isnull(Xuatkho,0)) as Inventory from\r\nItem " +
                "left join (select IDItem, isNull(sum(Receipt_Quantity),0) as Nhapkho from ReceiptInfo  " +
                "\r\n\t\t\t\tgroup by IDItem)Nhap\r\n\ton Item.ID = Nhap.IDItem\r\n\tleft join" +
                " (select IDItem, isNull(SUM(Order_Quantity),0) as Xuatkho from OrderInfo\r\n\t\t\t\tgroup by IDItem)Xuat\r\n\t" +
                "on Item.ID = Xuat.IDItem\r\n\tgroup by DisplayName\r\n");

            return Connection.selectQuery(s);
        }
        public DataTable SelectInventory()
        {
            string s = "select isnull(sum(isnull(Nhapkho,0)),0) as Receipt, isnull(sum(isnull(Xuatkho,0)),0) as 'Order'" +
                ", isnull(sum(isNull(Nhapkho,0) - isnull(Xuatkho,0)),0) as Inventory from" +
                "\r\nItem left join (select IDItem, isNull(sum(Receipt_Quantity),0) as Nhapkho from ReceiptInfo " +
                "\r\n\t\t\t\tgroup by IDItem)Nhap\r\n\ton Item.ID = Nhap.IDItem\r\n\t" +
                "left join (select IDItem, isNull(SUM(Order_Quantity),0) as Xuatkho from OrderInfo" +
                "\r\n\t\t\t\tgroup by IDItem)Xuat\r\n\ton Item.ID = Xuat.IDItem";

                        return Connection.selectQuery(s);

        }
        public DataTable SelectInventoryByDate()
        {
            string s = "\t\t\t\t\t\tselect isnull(sum(isnull(Nhapkho,0)),0)as Receipt, isnull(sum(isnull(Xuatkho,0)),0) as 'Order'," +
                " isnull(sum(isNull(Nhapkho,0) - isnull(Xuatkho,0)),0) as Inventory from\r\n\t\tItem left join" +
                " (select IDItem, isNull(sum(Receipt_Quantity),0) as Nhapkho from ReceiptInfo where IDReceipt in" +
                " (Select ID from Receipt where DATEDIFF(day, '" +Inventory.getDateStart + "', DateReceipt) >= 0\r\n\t\t" +
                "and DATEDIFF(day,DateReceipt,'" +Inventory.getDateEnd + "') >= 0)\r\n\t\t\t\t\t\tgroup by IDItem)Nhap\r\n\t\t\t" +
                "on Item.ID = Nhap.IDItem\r\n\t\t\tleft join (select IDItem, isNull(SUM(Order_Quantity),0) as Xuatkho from OrderInfo " +
                "where IDOrder in (Select ID from Orders where DATEDIFF(day, '" +Inventory.getDateStart + "', DateOrder)>= 0\r\n\t\tand " +
                "DATEDIFF(day,DateOrder, '" +Inventory.getDateEnd + "') >= 0)\r\n\t\t\t\t\t\tgroup by IDItem)Xuat\r\n\t\t\ton Item.ID = Xuat.IDItem\r\n ";
            
            /*string s = "\t\t\t\t\t\tselect sum(isnull(Nhapkho,0)) as Receipt, sum(isnull(Xuatkho, 0)) as 'Order'," +
                " sum(isNull(Nhapkho,0) - isnull(Xuatkho,0)) as Inventory from\r\n\t\tItem left join" +
                " (select IDItem, isNull(sum(Receipt_Quantity),0) as Nhapkho from ReceiptInfo where IDReceipt in" +
                " (Select ID from Receipt where DATEDIFF(day,DateReceipt,'" + Inventory.getDateEnd + "') >= 0)\r\n\t\t\t\t\t\tgroup by IDItem)Nhap\r\n\t\t\t" +
                "on Item.ID = Nhap.IDItem\r\n\t\t\tleft join (select IDItem, isNull(SUM(Order_Quantity),0) as Xuatkho from OrderInfo " +
                "where IDOrder in (Select ID from Orders where DATEDIFF(day, '" + Inventory.getDateStart + "', DateOrder)>= 0\r\n\t\tand " +
                "DATEDIFF(day,DateOrder, '" + Inventory.getDateEnd + "') >= 0)\r\n\t\t\t\t\t\tgroup by IDItem)Xuat\r\n\t\t\ton Item.ID = Xuat.IDItem\r\n ";*/
            
            return Connection.selectQuery(s);
        }
        public DataTable SelectInventory_DetailsByDate()
        {
            string s = "\t\tselect DisplayName as MobilePhone,  isnull(sum(isnull(Nhapkho,0)),0) as Receipt,isnull(sum(isnull(Xuatkho,0)),0) as 'Order'" +
                ", isnull(sum(isNull(Nhapkho,0) - isnull(Xuatkho,0)),0) as Inventory from\r\n\t\tItem " +
                "left join (select IDItem, isNull(sum(Receipt_Quantity),0) as Nhapkho from ReceiptInfo " +
                "where IDReceipt in (Select ID from Receipt where DATEDIFF(day, '" +Inventory.getDateStart + "', DateReceipt) >= 0\r\n\t\t" +
                "and DATEDIFF(day,DateReceipt,'" +Inventory.getDateEnd + "') >= 0)\r\n\t\t\t\t\t\tgroup by IDItem)Nhap\r\n\t\t\t" +
                "on Item.ID = Nhap.IDItem\r\n\t\t\tleft join (select IDItem, isNull(SUM(Order_Quantity),0) as Xuatkho from OrderInfo " +
                "where IDOrder in (Select ID from Orders where DATEDIFF(day, '" +Inventory.getDateStart + "', DateOrder)>= 0\r\n\t\tand" +
                " DATEDIFF(day,DateOrder, '" +Inventory.getDateEnd + "') >= 0)\r\n\t\t\t\t\t\tgroup by IDItem)Xuat\r\n\t\t\t" +
                "on Item.ID = Xuat.IDItem\r\n\t\tGroup by DisplayName\r\n\t\tOrder by Receipt Desc";

            /*string s = "\t\tselect DisplayName as MobilePhone, sum(isnull(Nhapkho,0)) as Receipt, sum(isnull(Xuatkho,0)) as 'Order'" +
                ", sum(isNull(Nhapkho,0) - isnull(Xuatkho,0)) as Inventory from\r\n\t\tItem " +
                "left join (select IDItem, isNull(sum(Receipt_Quantity),0) as Nhapkho from ReceiptInfo " +
                "where IDReceipt in (Select ID from Receipt where DATEDIFF(day,DateReceipt,'" + Inventory.getDateEnd + "') >= 0)\r\n\t\t\t\t\t\tgroup by IDItem)Nhap\r\n\t\t\t" +
                "on Item.ID = Nhap.IDItem\r\n\t\t\tleft join (select IDItem, isNull(SUM(Order_Quantity),0) as Xuatkho from OrderInfo " +
                "where IDOrder in (Select ID from Orders where DATEDIFF(day, '" + Inventory.getDateStart + "', DateOrder)>= 0\r\n\t\tand" +
                " DATEDIFF(day,DateOrder, '" + Inventory.getDateEnd + "') >= 0)\r\n\t\t\t\t\t\tgroup by IDItem)Xuat\r\n\t\t\t" +
                "on Item.ID = Xuat.IDItem\r\n\t\tGroup by DisplayName\r\n\t\tOrder by Receipt Desc";*/

            return Connection.selectQuery(s);
        }
        
        public DataTable SelectTop3()
        {
            string s = " select top 3 DisplayName as MobilePhone, isnull(sum(isnull(Xuatkho,0)),0) as 'Order'  \r\n\t\t\t\tfrom Item\r\n" +
                "left join (select IDItem, isNull(SUM(Order_Quantity),0) as Xuatkho from OrderInfo\r\n\t\t\t\t\t\t\t\t\t" +
                "group by IDItem)Xuat\r\n\t\t\t\t\t\ton Item.ID = Xuat.IDItem\r\n\t\t\t\t" +
                "group by DisplayName\r\n\t\t\t\torder by 'Order' desc\r\n ";

            return Connection.selectQuery(s);
        }
        public DataTable SelectTop3byDate()
        {
            string s = "select top 3 DisplayName as MobilePhone, isnull(sum(isnull(Xuatkho,0)),0) as 'Order' from Item" +
                " left join (select IDItem, isNull(SUM(Order_Quantity), 0) as Xuatkho from OrderInfo where IDOrder in (Select ID from Orders " +
                "where DATEDIFF(day, '" + Inventory.getDateStart + "', DateOrder)>= 0 and DATEDIFF(day,DateOrder, '" + Inventory.getDateEnd + "') >= 0)" +
                " group by IDItem)Xuat on Item.ID = Xuat.IDItem group by DisplayName order by 'Order' desc";

            return Connection.selectQuery(s);
        }

    }
}
