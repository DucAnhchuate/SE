﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO;

namespace DAL
{
    public class DAL_Item
    {

        private DTO_Item Item;

        public DAL_Item(string ID, string DisplayName, string IDSupplier)
        {
            Item = new DTO_Item(ID, DisplayName, IDSupplier);
        }
        public void addQuery()
        {
            string query = "insert into Item values (N'" + Item.getID + "',N'" + Item.getDisplayName + "',N'" + Item.getIDSupplier + "')";

            Connection.actionQuery(query);
        }
        public void updateQuery()
        {
            string query = "update Item set DisplayName = '" +Item.getDisplayName +"',IDSupplier = '" +Item.getIDSupplier+"' where ID like'"+ Item.getID +"'";

            Connection.actionQuery(query);
        }

        public void deleteQuery()
        {
            string query = "delete from Item where ID like '" + Item.getID + "'";

            Connection.actionQuery(query);
        }

        public DataTable selectQuery()
        {
            string s = "select DisplayName from Item group by DisplayName";

            return Connection.selectQuery(s);
        }

        public DataTable selectQuery1()
        {
            string s = "select * from Item";

            return Connection.selectQuery(s);
        }

        public DataTable getItemDesc()
        {
            string s = "select top 1 ID from Item order by ID desc";

            return Connection.selectQuery(s);
        }
        public DataTable getIDbySandD()
        {
            string s = "select ID from Item where DisplayName like '" + Item.getDisplayName + "' and IDsupplier like '" + Item.getIDSupplier + "'";

            return Connection.selectQuery(s);
        }
        public DataTable getIDbyD()
        {
            string s = "Select ID from Item where DisplayName like '" + Item.getDisplayName + "'";

            return Connection.selectQuery(s);
        }
    }
}
