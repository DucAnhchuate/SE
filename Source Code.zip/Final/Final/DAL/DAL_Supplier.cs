﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO;

namespace DAL
{
    public class DAL_Supplier
    {
        private DTO_Supplier Supplier;

        public DAL_Supplier(string ID, string DisplayName, string Address, string Phone, string Email, string MoreInfo) 
        {
            Supplier = new DTO_Supplier(ID, DisplayName, Address, Phone, Email, MoreInfo);
        }

        public void addQuery()
        {
            string query = "insert into Supplier values (N'" + Supplier.getID + "',N'" + Supplier.getDisplayName

                    + "',N'" + Supplier.getAddress + "',N'" + Supplier.getPhone + "',N'" + Supplier.getEmail + "',N'" + Supplier.getMoreInfo + "')";

            Connection.actionQuery(query);
        }

        public void updateQuery()
        {
            string query = "update Supplier set sup_Address = '" + Supplier.getAddress + "',Phone = '" + Supplier.getPhone +
            "', Email = '" + Supplier.getEmail + "', Moreinfo = '" + Supplier.getMoreInfo + "', DisplayName = '" + Supplier.getDisplayName + "'where ID like '" + Supplier.getID + "'";
            Connection.actionQuery(query);
        }

        public void deleteQuery() 
        {
            string query = "delete from Supplier where ID like '" + Supplier.getID + "'";

            Connection.actionQuery(query);
        }

        public DataTable selectQuery()
        {
            string s = "select * from Supplier";

            return Connection.selectQuery(s);
        }
        public DataTable getID()
        {
            string s = "select ID from Supplier where DisplayName like '" + Supplier.getDisplayName + "'";

            return Connection.selectQuery(s);
        }
        public DataTable getSupplierDesc()
        {
            string s = "select top 1 ID from Supplier order by ID desc";

            return Connection.selectQuery(s);
        }
        public DataTable getName()
        {
            string s = "select DisplayName from Supplier where ID like '" + Supplier.getID + "'";

            return Connection.selectQuery(s);
        }
        public DataTable checkName()
        {
            string s = "select * from Supplier where DisplayName like '" + Supplier.getDisplayName + "'";

            return Connection.selectQuery(s);
        }
    }
}
