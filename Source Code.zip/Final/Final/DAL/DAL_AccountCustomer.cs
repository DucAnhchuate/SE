﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using DTO;

namespace DAL
{
    public class DAL_AccountCustomer
    {
        DTO_AccountCustomer Account;

        public DAL_AccountCustomer(string Username, string Password, string isActive)
        {
            Account = new DTO_AccountCustomer(Username, Password, isActive);    
        }

        public void addQuery()
        {
            string query = "insert into AccountCustomer values (N'" + Account.getUsername + "',N'" + Account.getPassword

                    + "',N'" + Account.getIsActive +"')";

            Connection.actionQuery(query);
        }
        public void deleteQuery()
        {
            string query = "delete from AccountCustomer where Username like '" + Account.getUsername + "'";

            Connection.actionQuery(query);
        }
        public void updateStt()
        {
            string query = "update AccountCustomer set isActive ='" + Account.getIsActive + "' where Username like " +
                "'" + Account.getUsername + "'";

            Connection.actionQuery(query);
        }
        public DataTable selectQuery()
        {
            string s = "select * from AccountCustomer where Username like '" +Account.getUsername +"'";

            return Connection.selectQuery(s);
        }
    }
}
