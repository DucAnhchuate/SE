﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using DTO;

namespace DAL
{
    public class DAL_Customer
    {
        private DTO_Customer Customer;


        public DAL_Customer(string ID, string DisplayName, string Address, string Phone, string Email, string MoreInfo)
        {
            Customer = new DTO_Customer(ID, DisplayName, Address, Phone, Email, MoreInfo);
        }

        public void addQuery()
        {
            string query = "insert into Customer values (N'" + Customer.getID + "',N'" + Customer.getDisplayName

                    + "',N'" + Customer.getAddress + "',N'" + Customer.getPhone + "',N'" + Customer.getEmail + "',N'" + Customer.getMoreInfo + "')";

            Connection.actionQuery(query);
        }

        public void updateQuery() 
        {
            string query = "update Customer set cus_Address = '" + Customer.getAddress + "',Phone = '" + Customer.getPhone +
                "', Email = '" + Customer.getEmail + "', Moreinfo = '" + Customer.getMoreInfo + "', DisplayName = '" + Customer.getDisplayName + "'where ID like '" + Customer.getID + "'";
            Connection.actionQuery(query);
        }

        public void deleteQuery() 
        {
            string query = "delete from Customer where ID like '" + Customer.getID + "'";

            Connection.actionQuery(query);

            query = "delete from AccountCustomer where Username like '" + Customer.getID + "'";

            Connection.actionQuery(query);

        }

        public DataTable selectQuery()
        {
            string s = "select * from Customer";

            return Connection.selectQuery(s);
        }
        public DataTable getID()
        {
            string s = "select ID from Customer where DisplayName like '" + Customer.getDisplayName + "'";

            return Connection.selectQuery(s);
        }
        public DataTable getCustomerDesc()
        {
            string s = "select top 1 ID from Customer order by ID desc";

            return Connection.selectQuery(s);
        }
        public DataTable getEmail()
        {
            string s = "select Email from Customer where ID like '" + Customer.getID + "'";
            return Connection.selectQuery(s);
        }
        public DataTable checkPhone()
        {
            string s = "select * from Customer where Phone like '" + Customer.getPhone + "'";

            return Connection.selectQuery(s);
        }
    }
}
