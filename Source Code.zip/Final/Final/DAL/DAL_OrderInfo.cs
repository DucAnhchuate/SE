﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO;


namespace DAL
{
    public class DAL_OrderInfo
    {
        private DTO_OrderInfo OrderInfo;

           public DAL_OrderInfo(string ID, string IDItem, string IDOrder, int Quantity, float Price, float Total)
        {
            OrderInfo = new DTO_OrderInfo(ID, IDItem ,IDOrder, Quantity, Price, Total);
        }

        public void addQuery()
        {
            string query = "insert into OrderInfo values (N'" + OrderInfo.getID + "',N'" + OrderInfo.getIDItem

                    + "',N'" + OrderInfo.getIDOrder + "'," + OrderInfo.getOrderQuantity + 
                    "," + OrderInfo.getPrice + "," + OrderInfo.getTotal + ")";

            Connection.actionQuery(query);

        }

        public void updateQuery()
        {
            string query = "Update OrderInfo set IDitem = '" + OrderInfo.getIDItem + "', IDOrder = '" + OrderInfo.getIDOrder + "', Order_Quantity = " + OrderInfo.getOrderQuantity +
                ", Price = " + OrderInfo.getPrice +", Total = "+ OrderInfo.getTotal +" where ID like '" + OrderInfo.getID + "'";

            Connection.actionQuery(query);

        }

        public void deleteQuery()
        {
            string query = "delete from OrderInfo where ID like '" + OrderInfo.getID + "'";

            Connection.actionQuery(query);
        }
        public DataTable selectQuery()
        {
            string s = "select * from OrderInfo where IDOrder like '" + OrderInfo.getIDOrder + "'";

            return Connection.selectQuery(s);
        }

        public DataTable getOrderInfoDesc()
        {
            string s = "select top 1 ID from OrderInfo order by ID desc";

            return Connection.selectQuery(s);
        }
    }
}
