﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class DAL_Revenue
    {
        public DAL_Revenue() { }
        public DataTable getRevenue()
        {
            string s = "select Month(DateOrder) as 'Month', sum(Total) as Revenue from Orders where Year(DateOrder) = Year(getDate())\r\ngroup by Month(DateOrder)";

            return Connection.selectQuery(s);
        }
        public DataTable getBest()
        {
            string s = "\r\n\r\nselect DisplayName from Item inner join\r\n\t\t\t\t\t\t\t(select top 1 Max(Total) as Revenue ,IDItem from OrderInfo group by IDItem order by Max(Total) Desc)T\r\non Item.ID = T.IDItem";
            
                return Connection.selectQuery(s);
        }
    }
}
