﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO;

namespace DAL
{
    public class DAL_Order
    {
        private DTO_Order Order;


        public DAL_Order(string ID, string DateReceipt, string UserID, string Customer, string Status, string Payment, float Total)
        {
            Order = new DTO_Order(ID, DateReceipt, UserID,Customer, Status, Payment, Total);
        }

        public void addQuery()
        {
            string query = "insert into Orders values (N'" + Order.getID + "','" + Order.getDateOrder + 
                "',N'" + Order.getUserID +"',N'"+Order.getCustomer +"',N'" + Order.getStatus + "',N'" + Order.getPayment 
                + "'," + Order.getTotal + ")";

            Connection.actionQuery(query);
        }
        public void updateQuery()
        {
            string query = "update Orders set DateOrder = '" + Order.getDateOrder + "',Status = '" + Order.getStatus + 
                "', UserID = '" + Order.getUserID + "', Total = " + Order.getTotal + ", Payment = '" + Order.getPayment + "',Customer = '"+
                Order.getCustomer + "' where ID like '" + Order.getID + "'";

            Connection.actionQuery(query);
        }

        public void deleteQuery()
        {


            string query = "delete from OrderInfo where IDOrder like '" + Order.getID + "'";

            Connection.actionQuery(query);

            query = "delete from Orders where ID like '" + Order.getID + "'";

            Connection.actionQuery(query);

        }

        public DataTable selectQuery()
        {
            string s = "select * from Orders";

            return Connection.selectQuery(s);
        }

        public DataTable getOrderDesc()
        {
            string s = "select top 1 ID from Orders order by ID desc";

            return Connection.selectQuery(s);
        }

        public DataTable checkOrder()
        {
            string s = "select * from Orders where ID like '" + Order.getID + "'";

            return Connection.selectQuery(s);
        }
        public void updateTotal()
        {
            string s = "update Orders set Total = (select sum(Total) from OrderInfo where IDOrder like '" + Order.getID + "') where ID like '" + Order.getID + "'";

            Connection.actionQuery(s);
        }
        public DataTable CheckTotalPrice()
        {
            string s = "select * from OrderInfo where IDOrder like '" + Order.getID + "'";

            return Connection.selectQuery(s);

        }
    }
}
