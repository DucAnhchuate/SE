﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class DTO_Inventory
    {
        string DateStart, DateEnd, IDItem;

        int Order, Receipt, Inventory;

        public string getDateStart
        {
            get { return DateStart; }

            set { DateStart = value; }
        }

        public string getDateEnd
        {
            get { return DateEnd; }

            set { DateEnd = value; }
        }
        public string getIDItem
        {
            get { return IDItem; }

            set { IDItem = value; }
        }
        public int getOrder
        {
            get { return Order; }

            set { Order = value; }
        }
        public int getReceipt
        {
            get { return Receipt; }

            set { Receipt = value; }
        }
        public int getInventory
        {
            get { return Inventory; }

            set { Inventory = value; }
        }

        public DTO_Inventory(string DateStart, string DateEnd, string IDItem, int Order, int  Receipt, int Inventory)
        {
            this.DateStart = DateStart;

            this.DateEnd = DateEnd;

            this.IDItem = IDItem;

            this.Order = Order;
                            
            this.Receipt = Receipt;

            this.Inventory = Inventory;
        }
    }
}
