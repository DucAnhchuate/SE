﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class DTO_Item
    {
        private string ID, DisplayName, IDSupplier;

        public string getID
        {
            get { return this.ID; }

            set { this.ID = value; }
        }

        public string getDisplayName
        {
            get { return this.DisplayName; }

            set { this.DisplayName = value; }
        }
        public string getIDSupplier
        {
            get { return this.IDSupplier; }

            set { this.IDSupplier = value; }
        }

        public DTO_Item(string ID, string DisplayName, string IDSupplier)
        {
            this.ID = ID;

            this.DisplayName = DisplayName;

            this.IDSupplier = IDSupplier;
        }
        
    }
}
