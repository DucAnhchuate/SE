﻿ using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class DTO_Staff
    {
        private string ID, DisplayName, Username, Password;

        public string getID
        {
            get { return ID; }

            set { ID = value; }
        }
        
        public string getDisplayName
        {
            get { return DisplayName; }

            set { DisplayName = value; }
        }

        public string getPassword
        {
            get { return Password; }

            set { Password = value; }
        }

        public string getUserName
        {
            get { return Username; }

            set { Username = value; }
        }

        public DTO_Staff(string ID, string DisplayName, string Username, string Password) 
        {
            this.ID = ID;

            this.DisplayName = DisplayName;

            this.Username = Username;

            this.Password = Password;
        }
    }
}
