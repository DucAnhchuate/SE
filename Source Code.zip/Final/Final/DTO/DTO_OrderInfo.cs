﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class DTO_OrderInfo
    {
        private string ID, IDItem, IDOrder;

        private int OrderQuantity;

        private float Price, Total;

        public string getID
        {
            set { ID = value; }

            get { return ID; }
        }

        public string getIDItem
        {
            set { IDItem = value; }

            get { return IDItem; }
        }


        public string getIDOrder
        {
            get { return IDOrder; }

            set { IDOrder = value; }
        }
        
        public int getOrderQuantity
        {
            get { return OrderQuantity; }

            set { OrderQuantity = value; }
        }
        public float getPrice
        {
            get { return Price; }

            set { Price = value; }
        }
        public float getTotal
        {
            get { return Total; }

            set { Total = value; }
        }

        public DTO_OrderInfo(string ID, string IDItem , string IDOrder, int OrderQuantity, float Price, float Total)
        {
            this.ID = ID;

            this.IDItem = IDItem;


            this.IDOrder = IDOrder;

            this.OrderQuantity = OrderQuantity;

            this.Price = Price;

            this.Total = Total;
        }
    }
}
