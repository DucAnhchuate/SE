﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace DTO
{
    public class DTO_AccountCustomer
    {
        string Username, Password, isActive;

        public string getUsername
        {
            get { return this.Username; }

            set { this.Username = value; }
        }
        public string getPassword
        {
            get { return this.Password; }

            set { this.Password = value; }
        }
        public string getIsActive
        {
            get { return isActive; }

            set { isActive = value; }
        }
        public DTO_AccountCustomer(string Username, string Password, string isActive)
        {
            this.Username = Username;   

            this.Password = Password;

            this.isActive = isActive;
        }
    }
}
