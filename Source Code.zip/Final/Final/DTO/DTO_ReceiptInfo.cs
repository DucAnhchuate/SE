﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class DTO_ReceiptInfo
    {
        private string ID, IDItem, IDReceipt;

        private int ReceipQuantity;

        private float Receipt_Price, Order_Price;

        public string getID
        {
            set { ID = value; }

            get { return ID; }
        }

        public string getIDItem
        {
            set { IDItem = value; }

            get { return IDItem; }
        }

        public string getIDReceipt
        {
            set { IDReceipt = value; }

            get { return IDReceipt; }
        }
        public int getReceiptQuantity
        {
            set { ReceipQuantity = value; }

            get { return ReceipQuantity; }
        }

        public float getReceipt_Price
        {
            set { Receipt_Price = value; }

            get { return Receipt_Price; }
        }

        public float getOrder_Price
        {
            set { Order_Price = value; }

            get { return Order_Price; }
        }

        public DTO_ReceiptInfo(string ID, string IDItem, string IDReceipt, int ReceipQuantity, float Receipt_Price, float Order_Price)
        {
            this.ID = ID;

            this.IDItem = IDItem;

            this.IDReceipt = IDReceipt;

            this.ReceipQuantity = ReceipQuantity;

            this.Receipt_Price = Receipt_Price;

            this.Order_Price = Order_Price;
        }
    }
}
