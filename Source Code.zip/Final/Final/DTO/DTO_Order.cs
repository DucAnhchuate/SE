﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class DTO_Order
    {
        private string ID, DateOrder, UserID, Customer, Status, Payment;

        private float Total;
        public string getID
        {
            set { this.ID = value; }

            get { return this.ID; }
        }

        public string getDateOrder
        {
            get { return this.DateOrder; }

            set { this.DateOrder = value; }
        }
        public string getUserID
        {
            get { return this.UserID; }

            set { this.UserID = value; }
        }

        public string getStatus
        {
            get { return this.Status; }

            set { this.Status = value; }
        }
        public string getPayment
        {
            get { return this.Payment; }

            set { this.Payment = value; }
        }
        public float getTotal
        {
            get { return this.Total; }

            set { this.Total = value; }
        }
        public string getCustomer
        {
            get { return this.Customer; }

            set { this.Customer = value; }
        }
        public DTO_Order(string ID, string DateOrder, string UserID, string Customer, string Status, string Payment, float Total)
        {
            this.ID = ID;

            this.DateOrder = DateOrder;

            this.UserID = UserID;

            this.Status = Status;

            this.Payment = Payment;

            this.Total = Total;

            this.Customer = Customer;
        }
    }
}
