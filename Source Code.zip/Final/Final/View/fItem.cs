﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BUS;

namespace View
{
    public partial class fItem : Form
    {
        BUS_Item Item = new BUS_Item(null, null, null);

        BUS_Supplier Supplier = new BUS_Supplier(null, null, null, null, null, null);
        public fItem()
        {
            InitializeComponent();
        }

        private void fItem_Load(object sender, EventArgs e)
        {
            Form_Load();

            displaySup();

            txtPID.ReadOnly = true;

            cbSup.Enabled = true;

            grd1.AllowUserToAddRows = false;

            this.cbSup.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
        }

        public void Form_Load()
        {
            showGrd1();

            txtPName.Clear();

            enableButton(false);

            btAdd.Enabled = true;

            txtPID.Text = Item.CreateID();

            groupBox2.Enabled = true;

            clearText();

        }
        public void showGrd1()
        {
            grd1.DataSource = Item.selectQuery1();

            grd1.Columns[0].HeaderText = "ID";

            grd1.Columns[1].HeaderText = "Mobile Phone Name";

            grd1.Columns[2].HeaderText = "ID Supplier";


            grd1.Columns[1].Width = 150;

            grd1.Columns[0].Width = 60;

            grd1.Columns[2].Width = 80;


            foreach (DataGridViewColumn item in grd1.Columns)
            {
                item.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            }
            foreach (DataGridViewColumn col in grd1.Columns)
            {
                col.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            }

        }

        public void clearText()
        {
            txtPName.Clear();
        }
        public void enableButton(bool b)
        {
            btAdd.Enabled = b;

            btCancel.Enabled = b;

            btDelete.Enabled = b;

            btSave.Enabled = b;
        }
        public void displaySup()
        {
            cbSup.DataSource = Supplier.selectQuery();

            cbSup.DisplayMember = "DisplayName";

            cbSup.ValueMember = "ID";
        }

        private void btAdd_Click(object sender, EventArgs e)
        {
            string PID = txtPID.Text;

            string PName = txtPName.Text;

            string Sup = cbSup.SelectedValue.ToString();

            if (PName != "" && Sup != "")
            {
                Item = new BUS_Item(PID, PName, Sup);

                Item.addQuery();
                
                clearText();

                Form_Load();

                showGrd1();
            }
            else
            {
                MessageBox.Show("Please complete all information");
            }
            showGrd1();
        }

        private void grd1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                txtPID.Text = grd1.CurrentRow.Cells[0].Value.ToString();

                txtPName.Text = grd1.CurrentRow.Cells[1].Value.ToString();

                //cbSup.Text = grd1.CurrentRow.Cells[2].Value.ToString();

                string sup = new BUS_Supplier(grd1.CurrentRow.Cells[2].Value.ToString(), null, null, null, null, null).getName();

                cbSup.Text = sup;

                enableButton(false);

                btAdd.Enabled = false;

                btDelete.Enabled = true;

                btSave.Enabled =true ;

                cbSup.Enabled = true;
            }
        }

        private void btSave_Click(object sender, EventArgs e)
        {
            string PID = txtPID.Text;

            string PName = txtPName.Text;

            string Sup = cbSup.SelectedValue.ToString();

            if (PName != "" && Sup != "")
            {
                Item = new BUS_Item(PID, PName, Sup);

                Item.updateQuery();

                clearText();

                showGrd1();

                groupBox2.Enabled = true;

                Form_Load();
            }
            else
            {
                MessageBox.Show("Please complete all information");
            }
        }

        private void btDelete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you want to delete?", "", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                Item = new BUS_Item(txtPID.Text, null, null);

                Item.deleteQuery();

                Form_Load();
            }
        }

        private void btNew_Click(object sender, EventArgs e)
        {
            Form_Load();
        }

        private void btCancel_Click(object sender, EventArgs e)
        {
            Form_Load();
        }
    }
}
