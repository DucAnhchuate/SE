﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Lifetime;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BUS;
namespace View
{
    public partial class fSupplier : Form
    {
        BUS_Supplier Supplier = new BUS_Supplier(null, null, null, null, null, null);
        public fSupplier()
        {
            InitializeComponent();
        }

        private void fSupplier_Load(object sender, EventArgs e)
        {
            Form_Load();

            txtSID.ReadOnly = true;

            grd1.AllowUserToAddRows = false;

            grd1.Columns[0].HeaderText = "ID";

            grd1.Columns[1].HeaderText = "Supplier  Name";

            grd1.Columns[2].HeaderText = "Address";

            grd1.Columns[3].HeaderText = "Phone Number";

            grd1.Columns[4].HeaderText = "Email";

            grd1.Columns[5].HeaderText = "More";

            grd1.Columns[0].Width = 60;

            grd1.Columns[5].Width = 80;

            grd1.Columns[1].Width = 80;

            grd1.Columns[4].Width = 120;

            foreach (DataGridViewColumn item in grd1.Columns)
            {
                item.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            }
            foreach (DataGridViewColumn col in grd1.Columns)
            {
                col.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            }
        }
        public void Form_Load()
        {
            showGrd1();

            txtSName.Clear();

            enableButton(false);

            btAdd.Enabled = true;

            txtSID.Text = Supplier.CreateID();

            groupBox2.Enabled = true;

            clearText();

        }
        public void showGrd1()
        {
            grd1.DataSource = Supplier.selectQuery();
        }

        public void clearText()
        {
            txtSName.Clear();

            txtPhone.Clear();

            txtEmail.Clear();

            txtMore.Clear();

            txtAddress.Clear();

        }
        public void enableButton(bool b)
        {
            btAdd.Enabled = b;

            btCancel.Enabled = b;

            btDelete.Enabled = b;

            btSave.Enabled = b;
        }

        private void btAdd_Click(object sender, EventArgs e)
        {
            string SID = txtSID.Text;

            string SName = txtSName.Text;

            string Phone = txtPhone.Text;

            string More = txtMore.Text;

            string Address = txtAddress.Text;

            string Email = txtEmail.Text;

            if (SID != "" && SName != "" && Phone != "" && More != "" && Address != "")
            {
                Supplier = new BUS_Supplier(SID, SName, Address, Phone, Email, More);

                if (!Supplier.checkName())
                {
                    Supplier.addQuery();

                    clearText();

                    showGrd1();

                    Form_Load();
                }
                else
                {
                    MessageBox.Show("this Supplier is already registered");
                }

            }
            else
            {
                MessageBox.Show("Please complete all information");
            }
            showGrd1();
        }

        private void grd1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                txtSID.Text = grd1.CurrentRow.Cells[0].Value.ToString();

                txtSName.Text = grd1.CurrentRow.Cells[1].Value.ToString();

                txtPhone.Text = grd1.CurrentRow.Cells[3].Value.ToString();

                txtAddress.Text = grd1.CurrentRow.Cells[2].Value.ToString();

                txtMore.Text = grd1.CurrentRow.Cells[5].Value.ToString();

                txtEmail.Text = grd1.CurrentRow.Cells[4].Value.ToString();

                enableButton(false);

                btAdd.Enabled = false;

                btDelete.Enabled = true;

                btSave.Enabled = true;
            }
        }

        private void btSave_Click(object sender, EventArgs e)
        {
            string SID = txtSID.Text;

            string SName = txtSName.Text;

            string Phone = txtPhone.Text;

            string More = txtMore.Text;

            string Address = txtAddress.Text;

            string Email = txtEmail.Text;

            if (SID != "" && SName != "" && Phone != "" && More != "" && Address != "")
            {
                Supplier = new BUS_Supplier(SID, SName, Address, Phone, Email, More);

                Supplier.updateQuery();

                clearText();

                showGrd1();

                groupBox2.Enabled = true;

                Form_Load();
            }
            else
            {
                MessageBox.Show("Please complete all information");
            }
        }

        private void btDelete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you want to delete?", "", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                Supplier = new BUS_Supplier(txtSID.Text, null, null, null, null, null);

                Supplier.deleteQuery();

                Form_Load();
            }
        }

        private void btCancel_Click(object sender, EventArgs e)
        {
            Form_Load();

        }

        private void btNew_Click(object sender, EventArgs e)
        {
            Form_Load();
        }
    }
}
