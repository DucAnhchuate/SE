﻿namespace View
{


    partial class SEDataSet
    {
        partial class OrderInfoDataTable
        {
        }
    }
}

namespace View.SEDataSetTableAdapters {
    
    
    public partial class ReceiptInfoTableAdapter {
    }
}
