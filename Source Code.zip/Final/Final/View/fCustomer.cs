﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BUS;

namespace View
{
    public partial class fCustomer : Form
    {
        BUS_Customer Customer = new BUS_Customer(null, null, null, null, null, null);

        BUS_AccountCustomer Account = new BUS_AccountCustomer(null, null, null);

        string flag;
        public fCustomer()
        {
            InitializeComponent();

            grd1.AllowUserToAddRows = false;

            grd2.AllowUserToAddRows = false;
        }

        private void fCustomer_Load(object sender, EventArgs e)
        {
            Form_Load();

            this.cbStt.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
        }
        public void Form_Load()
        {
            showGrd1();

            showGrd2();

            txtCName.Clear();

            enableButton(false);

            btAdd.Enabled = true;

            btNew.Enabled = true;

            txtCID.Text = Customer.CreateID();

            grp1.Enabled = true;

            clearText();

            grp2.Enabled = false;

            grp1.Enabled = true;

            txtPhone.Enabled = true;

            txtCID.Enabled = false;
        }
        public void showGrd1()
        {
            grd1.DataSource = Customer.selectQuery();

            txtCID.ReadOnly = true;

            grd1.AllowUserToAddRows = false;

            grd1.Columns[0].HeaderText = "ID";

            grd1.Columns[1].HeaderText = "Customer Name";

            grd1.Columns[2].HeaderText = "Address";

            grd1.Columns[3].HeaderText = "Phone Number";

            grd1.Columns[4].HeaderText = "Email";

            grd1.Columns[5].HeaderText = "More";

            grd1.Columns[0].Width = 60;

            grd1.Columns[5].Width = 40;

            grd1.Columns[1].Width = 120;

            grd1.Columns[4].Width = 120;

            foreach (DataGridViewColumn item in grd1.Columns)
            {
                item.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            }
            foreach (DataGridViewColumn col in grd1.Columns)
            {
                col.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            }
        }
        public void showGrd2()
        {
            Account = new BUS_AccountCustomer(txtPhone.Text, null, null);

            grd2.DataSource = Account.selectQuery();

            txtCID.ReadOnly = true;

            grd2.AllowUserToAddRows = false;

            grd2.Columns[0].HeaderText = "Username";

            grd2.Columns[1].HeaderText = "Password";

            grd2.Columns[2].HeaderText = "Status";

            grd2.Columns[0].Width = 180;

            grd2.Columns[1].Width = 180;

            grd2.Columns[2].Width = 180;


            foreach (DataGridViewColumn item in grd2.Columns)
            {
                item.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            }
            foreach (DataGridViewColumn col in grd2.Columns)
            {
                col.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            }
        }

        public void clearText()
        {
            txtCName.Clear();

            txtPhone.Clear();

            txtEmail.Clear();

            txtMore.Clear();

            txtAddress.Clear();

        }
        public void enableButton(bool b)
        {
            btAdd.Enabled = b;

            btCancel.Enabled = b;

            btDelete.Enabled = b;

            btSave.Enabled = b;

            btSend.Enabled = b;
        }

        private void btNew_Click(object sender, EventArgs e)
        {
            Form_Load();

        }

        private void btAdd_Click(object sender, EventArgs e)
        {

            string CID = txtCID.Text;

            string CName = txtCName.Text;

            string Phone = txtPhone.Text;

            string More = txtMore.Text;

            string Address = txtAddress.Text;

            string Email = txtEmail.Text;

            if (CID != "" && CName != "" && Phone != "" && More != "" && Address != "")
            {
                Customer = new BUS_Customer(CID, CName, Address, Phone, Email, More);

                if (!Customer.checkPhone())
                {
                    Customer.addQuery();

                    Account = new BUS_AccountCustomer(Phone, Phone, "Active");

                    Account.addQuery();

                    clearText();

                    Form_Load();
                }
                else
                {
                    MessageBox.Show("This phone number is already registered, please use another phone number");
                }
            }
            else
            {
                MessageBox.Show("Please complete all information");
            }
            showGrd1();
        }

        private void btSave_Click(object sender, EventArgs e)
        {
            string CID = txtCID.Text;

            string CName = txtCName.Text;

            string Phone = txtPhone.Text;

            string More = txtMore.Text;

            string Address = txtAddress.Text;

            string Email = txtEmail.Text;

            if (flag.Equals("click 1"))
            {

                if (CID != "" && CName != "" && Phone != "" && More != "" && Address != "")
                {
                    Customer = new BUS_Customer(CID, CName, Address, Phone, Email, More);

                    Customer.updateQuery();

                    Account = new BUS_AccountCustomer(Phone,null,null);

                    clearText();

                    grp1.Enabled = true;

                    Form_Load();
                }
                else
                {
                    MessageBox.Show("Please complete all information");
                }
            }
            else if (flag.Equals("click 2")){

                Account = new BUS_AccountCustomer(txtPhone.Text, null, cbStt.Text);

                Account.updateStt();

                Form_Load();
            }
        }

        private void btDelete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you want to delete?", "", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                Customer = new BUS_Customer(txtCID.Text, null, null, null, null, null);

                Customer.deleteQuery();

                Account = new BUS_AccountCustomer(txtPhone.Text, null, null) ;

                Account.deleteQuery();

                Form_Load();
            }
        }

        private void btCancel_Click(object sender, EventArgs e)
        {
            Form_Load();

        }

        private void grd1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                txtCID.Text = grd1.CurrentRow.Cells[0].Value.ToString();

                txtCName.Text = grd1.CurrentRow.Cells[1].Value.ToString();

                txtPhone.Text = grd1.CurrentRow.Cells[3].Value.ToString();

                txtAddress.Text = grd1.CurrentRow.Cells[2].Value.ToString();

                txtMore.Text = grd1.CurrentRow.Cells[5].Value.ToString();

                txtEmail.Text = grd1.CurrentRow.Cells[4].Value.ToString();

                enableButton(false);

                btAdd.Enabled = false;

                btDelete.Enabled = true;

                btSave.Enabled = true;

                flag = "click 1";

                showGrd2();

                txtPhone.Enabled = false;

                grp1.Enabled = true;

                btSend.Enabled = true;
            }
        }

        private void grd2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            grp1.Enabled = false;

            grp2.Enabled = true;

            txtPhone.Text = grd2.CurrentRow.Cells[0].Value.ToString();

            cbStt.Text = grd2.CurrentRow.Cells[2].Value.ToString();

            flag = "click 2";

            enableButton(false);

            btSave.Enabled = true;

            btCancel.Enabled = true;    
        }

        private void btSend_Click(object sender, EventArgs e)
        {
                Customer = new BUS_Customer(txtCID.Text, null, null, null, null, null);

                string Email = Customer.getEmail();

                string content = "You have successfully registered\n" +
                "\nUsername: " + txtPhone.Text + "" +
                "\nPassword: " +txtPhone.Text + "";

                fEmail form1 = new fEmail(Email, content);

                this.Hide();

                form1.ShowDialog();

                this.Show();
        }
    }
}
