﻿namespace View
{
    partial class fInventory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fInventory));
            this.btSearch2 = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.date3 = new System.Windows.Forms.DateTimePicker();
            this.date4 = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.grd1 = new System.Windows.Forms.DataGridView();
            this.btSearch1 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtTop3V = new System.Windows.Forms.Label();
            this.txtName3 = new System.Windows.Forms.Label();
            this.txtTop2V = new System.Windows.Forms.Label();
            this.txtName2 = new System.Windows.Forms.Label();
            this.txtTop1V = new System.Windows.Forms.Label();
            this.txtName1 = new System.Windows.Forms.Label();
            this.btSearch3 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.date1 = new System.Windows.Forms.DateTimePicker();
            this.date2 = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.date5 = new System.Windows.Forms.DateTimePicker();
            this.date6 = new System.Windows.Forms.DateTimePicker();
            this.label9 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtO = new System.Windows.Forms.TextBox();
            this.txtR = new System.Windows.Forms.TextBox();
            this.txtI = new System.Windows.Forms.TextBox();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grd1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btSearch2
            // 
            this.btSearch2.BackColor = System.Drawing.Color.Bisque;
            this.btSearch2.FlatAppearance.BorderSize = 0;
            this.btSearch2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btSearch2.Location = new System.Drawing.Point(634, 57);
            this.btSearch2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btSearch2.Name = "btSearch2";
            this.btSearch2.Size = new System.Drawing.Size(138, 40);
            this.btSearch2.TabIndex = 3;
            this.btSearch2.Text = "Search";
            this.btSearch2.UseVisualStyleBackColor = false;
            this.btSearch2.Click += new System.EventHandler(this.btSearch2_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.Transparent;
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.date3);
            this.groupBox3.Controls.Add(this.date4);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.grd1);
            this.groupBox3.Controls.Add(this.btSearch2);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(738, 45);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox3.Size = new System.Drawing.Size(909, 765);
            this.groupBox3.TabIndex = 4;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Inventory Details";
            this.groupBox3.Enter += new System.EventHandler(this.groupBox3_Enter);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(384, 65);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 25);
            this.label2.TabIndex = 9;
            this.label2.Text = "To";
            // 
            // date3
            // 
            this.date3.CustomFormat = "dd/MM/yyyy";
            this.date3.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.date3.Location = new System.Drawing.Point(188, 58);
            this.date3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.date3.Name = "date3";
            this.date3.Size = new System.Drawing.Size(172, 30);
            this.date3.TabIndex = 6;
            // 
            // date4
            // 
            this.date4.CustomFormat = "dd/MM/yyyy";
            this.date4.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.date4.Location = new System.Drawing.Point(430, 58);
            this.date4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.date4.Name = "date4";
            this.date4.Size = new System.Drawing.Size(180, 30);
            this.date4.TabIndex = 8;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(118, 65);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 25);
            this.label4.TabIndex = 7;
            this.label4.Text = "From";
            // 
            // grd1
            // 
            this.grd1.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.grd1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grd1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.grd1.Location = new System.Drawing.Point(4, 108);
            this.grd1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.grd1.Name = "grd1";
            this.grd1.RowHeadersWidth = 62;
            this.grd1.Size = new System.Drawing.Size(901, 652);
            this.grd1.TabIndex = 4;
            // 
            // btSearch1
            // 
            this.btSearch1.BackColor = System.Drawing.Color.Bisque;
            this.btSearch1.FlatAppearance.BorderSize = 0;
            this.btSearch1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btSearch1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btSearch1.ForeColor = System.Drawing.Color.Black;
            this.btSearch1.Location = new System.Drawing.Point(548, 60);
            this.btSearch1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btSearch1.Name = "btSearch1";
            this.btSearch1.Size = new System.Drawing.Size(138, 42);
            this.btSearch1.TabIndex = 45;
            this.btSearch1.Text = "Search";
            this.btSearch1.UseVisualStyleBackColor = false;
            this.btSearch1.Click += new System.EventHandler(this.btSearch1_Click_1);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(286, 143);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 25);
            this.label7.TabIndex = 48;
            this.label7.Text = "ORDER";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(434, 143);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(136, 25);
            this.label6.TabIndex = 47;
            this.label6.Text = "INVENTORY";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(99, 146);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(104, 25);
            this.label5.TabIndex = 46;
            this.label5.Text = "RECEIPT";
            // 
            // txtTop3V
            // 
            this.txtTop3V.AutoSize = true;
            this.txtTop3V.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTop3V.Location = new System.Drawing.Point(274, 100);
            this.txtTop3V.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtTop3V.Name = "txtTop3V";
            this.txtTop3V.Size = new System.Drawing.Size(75, 25);
            this.txtTop3V.TabIndex = 66;
            this.txtTop3V.Text = "label14";
            this.txtTop3V.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtName3
            // 
            this.txtName3.AutoSize = true;
            this.txtName3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtName3.Location = new System.Drawing.Point(24, 102);
            this.txtName3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtName3.Name = "txtName3";
            this.txtName3.Size = new System.Drawing.Size(75, 25);
            this.txtName3.TabIndex = 65;
            this.txtName3.Text = "label15";
            this.txtName3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtTop2V
            // 
            this.txtTop2V.AutoSize = true;
            this.txtTop2V.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTop2V.Location = new System.Drawing.Point(274, 74);
            this.txtTop2V.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtTop2V.Name = "txtTop2V";
            this.txtTop2V.Size = new System.Drawing.Size(75, 25);
            this.txtTop2V.TabIndex = 64;
            this.txtTop2V.Text = "label12";
            this.txtTop2V.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtName2
            // 
            this.txtName2.AutoSize = true;
            this.txtName2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtName2.Location = new System.Drawing.Point(24, 75);
            this.txtName2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtName2.Name = "txtName2";
            this.txtName2.Size = new System.Drawing.Size(75, 25);
            this.txtName2.TabIndex = 63;
            this.txtName2.Text = "label13";
            this.txtName2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtTop1V
            // 
            this.txtTop1V.AutoSize = true;
            this.txtTop1V.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTop1V.Location = new System.Drawing.Point(274, 48);
            this.txtTop1V.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtTop1V.Name = "txtTop1V";
            this.txtTop1V.Size = new System.Drawing.Size(75, 25);
            this.txtTop1V.TabIndex = 62;
            this.txtTop1V.Text = "label11";
            this.txtTop1V.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtName1
            // 
            this.txtName1.AutoSize = true;
            this.txtName1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtName1.Location = new System.Drawing.Point(24, 49);
            this.txtName1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtName1.Name = "txtName1";
            this.txtName1.Size = new System.Drawing.Size(75, 25);
            this.txtName1.TabIndex = 61;
            this.txtName1.Text = "label10";
            this.txtName1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btSearch3
            // 
            this.btSearch3.BackColor = System.Drawing.Color.Bisque;
            this.btSearch3.FlatAppearance.BorderSize = 0;
            this.btSearch3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btSearch3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btSearch3.ForeColor = System.Drawing.Color.Black;
            this.btSearch3.Location = new System.Drawing.Point(548, 434);
            this.btSearch3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btSearch3.Name = "btSearch3";
            this.btSearch3.Size = new System.Drawing.Size(138, 40);
            this.btSearch3.TabIndex = 60;
            this.btSearch3.Text = "Search";
            this.btSearch3.UseVisualStyleBackColor = false;
            this.btSearch3.Click += new System.EventHandler(this.btSearch3_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(291, 71);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(36, 25);
            this.label1.TabIndex = 70;
            this.label1.Text = "To";
            // 
            // date1
            // 
            this.date1.CustomFormat = "dd/MM/yyyy";
            this.date1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.date1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.date1.Location = new System.Drawing.Point(94, 63);
            this.date1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.date1.Name = "date1";
            this.date1.Size = new System.Drawing.Size(172, 30);
            this.date1.TabIndex = 67;
            // 
            // date2
            // 
            this.date2.CustomFormat = "dd/MM/yyyy";
            this.date2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.date2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.date2.Location = new System.Drawing.Point(334, 65);
            this.date2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.date2.Name = "date2";
            this.date2.Size = new System.Drawing.Size(172, 30);
            this.date2.TabIndex = 69;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(26, 71);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 25);
            this.label3.TabIndex = 68;
            this.label3.Text = "From";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(292, 442);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(36, 25);
            this.label8.TabIndex = 74;
            this.label8.Text = "To";
            // 
            // date5
            // 
            this.date5.CustomFormat = "dd/MM/yyyy";
            this.date5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.date5.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.date5.Location = new System.Drawing.Point(96, 437);
            this.date5.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.date5.Name = "date5";
            this.date5.Size = new System.Drawing.Size(172, 30);
            this.date5.TabIndex = 71;
            // 
            // date6
            // 
            this.date6.CustomFormat = "dd/MM/yyyy";
            this.date6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.date6.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.date6.Location = new System.Drawing.Point(336, 438);
            this.date6.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.date6.Name = "date6";
            this.date6.Size = new System.Drawing.Size(172, 30);
            this.date6.TabIndex = 73;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(26, 442);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(57, 25);
            this.label9.TabIndex = 72;
            this.label9.Text = "From";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(76, 177);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(150, 146);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 75;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(254, 177);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(150, 146);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 76;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(428, 177);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(142, 146);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 77;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(30, 532);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(238, 240);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 78;
            this.pictureBox4.TabStop = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtTop3V);
            this.groupBox1.Controls.Add(this.txtName3);
            this.groupBox1.Controls.Add(this.txtTop2V);
            this.groupBox1.Controls.Add(this.txtName2);
            this.groupBox1.Controls.Add(this.txtTop1V);
            this.groupBox1.Controls.Add(this.txtName1);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(308, 571);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Size = new System.Drawing.Size(388, 154);
            this.groupBox1.TabIndex = 79;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Best Seller";
            // 
            // txtO
            // 
            this.txtO.BackColor = System.Drawing.Color.PapayaWhip;
            this.txtO.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtO.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtO.Location = new System.Drawing.Point(254, 332);
            this.txtO.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtO.Name = "txtO";
            this.txtO.ReadOnly = true;
            this.txtO.Size = new System.Drawing.Size(150, 30);
            this.txtO.TabIndex = 80;
            this.txtO.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtR
            // 
            this.txtR.BackColor = System.Drawing.Color.PapayaWhip;
            this.txtR.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtR.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtR.Location = new System.Drawing.Point(76, 332);
            this.txtR.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtR.Name = "txtR";
            this.txtR.ReadOnly = true;
            this.txtR.Size = new System.Drawing.Size(150, 30);
            this.txtR.TabIndex = 81;
            this.txtR.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtI
            // 
            this.txtI.BackColor = System.Drawing.Color.PapayaWhip;
            this.txtI.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtI.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtI.Location = new System.Drawing.Point(428, 329);
            this.txtI.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtI.Name = "txtI";
            this.txtI.ReadOnly = true;
            this.txtI.Size = new System.Drawing.Size(142, 30);
            this.txtI.TabIndex = 82;
            this.txtI.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // fInventory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PapayaWhip;
            this.ClientSize = new System.Drawing.Size(1674, 835);
            this.Controls.Add(this.txtI);
            this.Controls.Add(this.txtR);
            this.Controls.Add(this.txtO);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.date5);
            this.Controls.Add(this.date6);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.date1);
            this.Controls.Add(this.date2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btSearch3);
            this.Controls.Add(this.btSearch1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.groupBox3);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "fInventory";
            this.Text = "INVENTORY";
            this.Load += new System.EventHandler(this.fOrder_Load);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grd1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btSearch2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btSearch1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker date3;
        private System.Windows.Forms.DateTimePicker date4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView grd1;
        private System.Windows.Forms.Label txtTop3V;
        private System.Windows.Forms.Label txtName3;
        private System.Windows.Forms.Label txtTop2V;
        private System.Windows.Forms.Label txtName2;
        private System.Windows.Forms.Label txtTop1V;
        private System.Windows.Forms.Label txtName1;
        private System.Windows.Forms.Button btSearch3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker date1;
        private System.Windows.Forms.DateTimePicker date2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DateTimePicker date5;
        private System.Windows.Forms.DateTimePicker date6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtO;
        private System.Windows.Forms.TextBox txtR;
        private System.Windows.Forms.TextBox txtI;
    }
}