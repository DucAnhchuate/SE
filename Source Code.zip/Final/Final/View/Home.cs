﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace View
{
    public partial class Home : Form
    {
        private string buffer;

        public Home()
        {
            InitializeComponent();
        }

        private void Home_Load(object sender, EventArgs e)
        {                        
            txtUser.Text = buffer;

            txtUser.Enabled = false;

            OpenFormChild(new fStatictis(), body);


        }

        public Home(string user): this()
        {
            buffer = user;
        }

        private Form currentFormChild;

        private void OpenFormChild(Form childForm, Panel body)
        {
            if (currentFormChild != null)
            {
                currentFormChild.Close();
            }

            currentFormChild = childForm;

            childForm.TopLevel = false;

            childForm.FormBorderStyle = FormBorderStyle.None;

            childForm.Dock = DockStyle.Fill;

            body.Controls.Add(childForm);

            body.Tag = childForm;

            childForm.BringToFront();

            childForm.Show();
        }

        private void panel_top_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btR_Click(object sender, EventArgs e)
        {
            OpenFormChild(new fReceipt(buffer), body);
        }

        private void btI_Click(object sender, EventArgs e)
        {
            OpenFormChild(new fInventory(), body);

        }

        private void btO_Click(object sender, EventArgs e)
        {
            OpenFormChild(new fOrder(buffer), body);
        }

        private void btPhone_Click(object sender, EventArgs e)
        {
            if (buffer == "admin")
            {
                OpenFormChild(new fItem(), body);
            }
            else
            {
                MessageBox.Show("Only admin is allowed to use this function");
            }
        }

        private void btSup_Click(object sender, EventArgs e)
        {
            if (buffer == "admin")
            {
                OpenFormChild(new fSupplier(), body);
            }
            else
            {
                MessageBox.Show("Only admin is allowed to use this function");
            }
        }

        private void btCus_Click(object sender, EventArgs e)
        {      
            OpenFormChild(new fCustomer(), body);
            
        }

        private void btRevenue_Click(object sender, EventArgs e)
        {
            OpenFormChild(new fStatictis(), body);
        }

        private void btChange_Click(object sender, EventArgs e)
        {

        }

        private void btAdd_Click(object sender, EventArgs e)
        {

        }

        private void addAccountToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (buffer == "admin")
            {
                OpenFormChild(new fStaff(), body);

            }
            else
            {
                MessageBox.Show("Only admin is allowed to use this function");
            }
        }

        private void cHANGEPASSWORDToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ChangePass form1 = new ChangePass(txtUser.Text);

            this.Hide();

            form1.ShowDialog();

            this.Show();
        }
    }
}
