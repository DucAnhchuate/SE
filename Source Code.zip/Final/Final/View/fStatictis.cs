﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BUS;

namespace View
{
    public partial class fStatictis : Form
    {
        public fStatictis()
        {
            InitializeComponent();
        }

        private void fStatictis_Load(object sender, EventArgs e)
        {
            BUS_Revenue re = new BUS_Revenue();

            DataTable dt = re.getRevenue();

            chartV.DataSource = dt;

            chartV.ChartAreas["ChartArea1"].AxisX.Title = "Month";

            chartV.ChartAreas["ChartArea1"].AxisY.Title = "Revenue";

            chartV.ChartAreas["ChartArea1"].AxisX.Interval = 1;

            chartV.Series["Month"].XValueMember = "Month";

            chartV.Series["Month"].YValueMembers = "Revenue";

            grd1.DataSource = dt;

            grd1.Columns[0].HeaderText = "MONTH";

            grd1.Columns[1].HeaderText = "REVENUE";

            label2.Text = re.getBest();
        }

    }
}
