﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BUS;

namespace View
{
    public partial class fInventory : Form
    {
        BUS_Inventory Inventory = new BUS_Inventory(null, null, null, 0,0 ,0);
        public fInventory()
        {
            InitializeComponent();
        }

        private void fOrder_Load(object sender, EventArgs e)
        {
            grd1.AllowUserToAddRows = false;

            grd1.AllowUserToDeleteRows = false;

            /*txtI.ReadOnly = true;

            txtO.ReadOnly = true;   

            txtR.ReadOnly = true;
            
            txtName1.ReadOnly = true;

            txtName2.ReadOnly = true;

            txtName3.ReadOnly = true;

            txtTop1V.ReadOnly = true;

            txtTop2V.ReadOnly = true;   

            txtTop3V.ReadOnly = true;*/

            formload();
        }
        private void formload()
        {
            txtO.Text = Inventory.getOrder().ToString();

            txtR.Text = Inventory.getReceipt().ToString();

            txtI.Text = Inventory.getInventory().ToString();

            txtName1.Text = Inventory.getNameTop1().ToString();

            txtName2.Text = Inventory.getNameTop2().ToString();

            txtName3.Text = Inventory.getNameTop3().ToString();

            txtTop1V.Text = Inventory.getOrderTop1().ToString();

            txtTop3V.Text = Inventory.getOrderTop2().ToString();

            txtTop2V.Text = Inventory.getOrderTop3().ToString();

            showGrdDefault();


        }
        private void showGrdDefault()
        {
            grd1.DataSource = Inventory.selectInventory();

            grd1.Columns[0].HeaderText = "RECEIPT";

            grd1.Columns[1].HeaderText = "ORDER";

            grd1.Columns[2].HeaderText = "INVENTORY";

            grd1.Columns[0].Width = 180;

            grd1.Columns[1].Width = 180;

            grd1.Columns[2].Width = 180;
        }
        
        
        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }
        private void groupBox5_Enter(object sender, EventArgs e)
        {

        }

        private void btSearch2_Click(object sender, EventArgs e)
        {
            string DateStart = date3.Value.ToString("yyyy-MM-dd");

            string DateEnd = date4.Value.ToString("yyyy-MM-dd");

            Inventory = new BUS_Inventory(DateStart, DateEnd, null, 0, 0, 0);

            grd1.DataSource = Inventory.selectInventorybyDate();

        }
        private void groupBox6_Enter(object sender, EventArgs e)
        {

        }

        private void btSearch1_Click_1(object sender, EventArgs e)
        {
            string DateStart = date1.Value.ToString("yyyy-MM-dd");

            string DateEnd = date2.Value.ToString("yyyy-MM-dd");

            Inventory = new BUS_Inventory(DateStart, DateEnd, null, 0, 0, 0);

            txtO.Text = Inventory.getOrderbyDate().ToString();

            txtR.Text = Inventory.getReceiptbyDate().ToString();

            txtI.Text = Inventory.getInventorybyDate().ToString();
        }

        private void btSearch3_Click(object sender, EventArgs e)
        {
            string DateStart = date5.Value.ToString("yyyy-MM-dd");

            string DateEnd = date6.Value.ToString("yyyy-MM-dd");

            Inventory = new BUS_Inventory(DateStart, DateEnd, null, 0, 0, 0);

            txtName1.Text = Inventory.getNameTop1byDate().ToString();

            txtName2.Text = Inventory.getNameTop2byDate().ToString();

            txtName3.Text = Inventory.getNameTop3byDate().ToString();

            txtTop1V.Text = Inventory.getOrderTop1byDate().ToString();

            txtTop2V.Text = Inventory.getOrderTop2byDate().ToString();

            txtTop3V.Text = Inventory.getOrderTop3byDate().ToString();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
