﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;

namespace View
{
    public partial class fEmail : Form
    {
        string email;

        string Content;
        public fEmail()
        {
            InitializeComponent();
        }
        public fEmail(string email, string content): this()
        {
            this.email = email;

            this.Content = content;
        }
        private void fEmail_Load(object sender, EventArgs e)
        {
            txtCus.Text = email;
            
            txtCompany.Focus();

            txtCompany.Text = "521h0005@student.tdtu.edu.vn";

            txtContent.Text = Content;
        }

        private void btSend_Click(object sender, EventArgs e)
        {
            string from, to, pass, content;

            to = txtCus.Text;

            from = txtCompany.Text;

            pass = txtPass.Text;

            content = txtContent.Text;

            MailMessage mail = new MailMessage();

            mail.To.Add(to);

            mail.From = new MailAddress(from);

            mail.Subject = "Anh Hao Co.,LTD";
              
            mail.Body = content;

            SmtpClient smtp = new SmtpClient("smtp.gmail.com");

            smtp.EnableSsl = true;

            smtp.Port = 587;

            smtp.DeliveryMethod = SmtpDeliveryMethod.Network;

            smtp.Credentials = new NetworkCredential(from, pass);

            try
            {
                smtp.Send(mail);

                MessageBox.Show("Successfully");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
