﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BUS;
using BUS.SEDataSetTableAdapters;

namespace View
{
    public partial class fStaff : Form
    {
        BUS_Staff user = new BUS_Staff(null, null, null, null);

        public fStaff()
        {
            InitializeComponent();
        }

        private void fStaff_Load(object sender, EventArgs e)
        {
            txtUsername.ReadOnly = true;

            formload();
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }
        public void formload()
        {
            txtUsername.Text = user.CreateID();

            user = new BUS_Staff(null, null, null, null);

            dataGridView1.DataSource = user.selectQuery();

            dataGridView1.Columns[0].HeaderText = "Staff ID";

            dataGridView1.Columns[1].HeaderText = "Staff Name";

            dataGridView1.Columns[2].HeaderText = "Username";

            dataGridView1.Columns[3].HeaderText = "Password";

            dataGridView1.Columns[0].Width = 110;
            dataGridView1.Columns[1].Width = 120;
            dataGridView1.Columns[2].Width = 110;
            dataGridView1.Columns[3].Width = 120;

            btDe.Enabled = false;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            BUS_Staff user = new BUS_Staff(null, null, null, null);

            string ID = user.CreateID();

            string Pass = txtPass.Text;

            txtUsername.Text = ID;

            user  = new BUS_Staff(ID, ID, ID, Pass);

            if (txtPass.Text != "")
            {
                user.addQuery();

                MessageBox.Show("Add Staff successfully");

                formload();
            }
            else
            {
                MessageBox.Show("Please enter password");
            }

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtUsername.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();

            btDe.Enabled = true;

        }

        private void btDe_Click(object sender, EventArgs e)
        {
            if (!txtUsername.Text.Equals("admin"))
            {
                user = new BUS_Staff(txtUsername.Text, null, null, null);

                if (MessageBox.Show("Do you want to delete?", "", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    user.deleteQuery();
                }
                formload();
            }
            else
            {
                MessageBox.Show("You are not allowed to delete admin ");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            formload();
        }
    }
}
