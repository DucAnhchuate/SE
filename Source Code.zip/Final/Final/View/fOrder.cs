﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;
using BUS;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Security.Cryptography;
using System.Diagnostics;
using System.Xml.Linq;
using Microsoft.Office.Interop.Excel;

using DataTable = System.Data.DataTable;

namespace View
{
    public partial class fOrder : Form
    {
        BUS_Customer Customer = new BUS_Customer(null, null, null, null, null, null);

        BUS_Item Item = new BUS_Item(null, null, null);

        BUS_Staff User = new BUS_Staff(null, null, null, null);

        BUS_ReceiptInfo Info = new BUS_ReceiptInfo(null, null, null, 0, 0, 0);

        BUS_OrderInfo OInfo = new BUS_OrderInfo(null, null, null, 0,0,0);

        BUS_Order Order = new BUS_Order(null,null, null, null, null, null, 0);

        string user = null;

        string flag;

        public fOrder()
        {
            InitializeComponent();
        }
        public fOrder(string user) : this()
        {
            this.user = user;

        }
        private void fOrder_Load(object sender, EventArgs e)
        {
            displayCustomer();

            displayPName();

            Form_Load();

            User = new BUS_Staff(null, null, user, null);

            txtUser.Text = User.getID();

            txtTotal.ReadOnly = true;

            this.cbStt.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;

            this.cbPName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;

            this.cbPay.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;

            this.cbCus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;

            this.cbIDItem.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;

            txtOID.ReadOnly = true;

            txtUser.ReadOnly = true;

            grd1.AllowUserToAddRows = false;

            grd2.AllowUserToAddRows = false;

        }
        public void Form_Load()
        {
            showGrd1();

            showGrd2();

            txtOID.Clear();

            date.Enabled = true;

            cbStt.Enabled = true;

            enableButton(false);

            btAdd.Enabled = true;

            txtOID.Text = Order.CreateID();

            groupBox2.Enabled = true;

            clearText();

        }
        private void displayCustomer()
        {
            cbCus.DataSource = Customer.selectQuery();

            cbCus.DisplayMember = "DisplayName";

            cbCus.ValueMember = "ID";
        }
        public void displayPName()
        {
            cbPName.DataSource = Item.selectQuery();

            cbPName.DisplayMember = "DisplayName";

            cbPName.ValueMember = "DisplayName";
        }
        public void displayIDItem()
        {
            cbIDItem.DataSource = Item.getIDbyD();

            cbIDItem.DisplayMember = "ID";

            cbIDItem.ValueMember = "ID";
        }
        public void showGrd1()
        {
            grd1.DataSource = Order.selectQuery();

            grd1.Columns[1].DefaultCellStyle.Format = "dd/MM/yyyy";

            grd1.Columns[0].Width = 65;

            grd1.Columns[1].Width = 75;

            grd1.Columns[2].Width = 50;

            grd1.Columns[3].Width = 60;

            grd1.Columns[4].Width = 75;

            grd1.Columns[5].Width = 50;

            grd1.Columns[6].Width = 65;

            grd1.Columns[0].HeaderText = "ID";

            grd1.Columns[1].HeaderText = "Date";

            grd1.Columns[2].HeaderText = "by User";

            grd1.Columns[3].HeaderText = "Customer ID ";

            grd1.Columns[4].HeaderText = "Status";

            grd1.Columns[5].HeaderText = "Payment";

            grd1.Columns[6].HeaderText = "Total Price";

            foreach (DataGridViewColumn item in grd1.Columns)
            {
                item.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            }
            foreach (DataGridViewColumn col in grd1.Columns)
            {
                col.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            }
        }

        public void showGrd2()
        {
            OInfo = new BUS_OrderInfo(null, null, txtOID.Text, 0, 0, 0);

            grd2.DataSource = OInfo.selectQuery();

            grd2.Columns[0].Width = 60;

            grd2.Columns[1].Width = 75;

            grd2.Columns[2].Width = 75;

            grd2.Columns[3].Width = 75;

            grd2.Columns[4].Width = 75;

            grd2.Columns[5].Width = 75;

            foreach (DataGridViewColumn item in grd2.Columns)
            {
                item.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            }
            foreach (DataGridViewColumn col in grd2.Columns)
            {
                col.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            }
            grd2.Columns[0].HeaderText = "ID";

            grd2.Columns[1].HeaderText = "ID Item";

            grd2.Columns[2].HeaderText = "ID Order";

            grd2.Columns[3].HeaderText = "Quantity";

            grd2.Columns[4].HeaderText = "Price/Item";

            grd2.Columns[5].HeaderText = "Total";
        }
        public void clearText()
        {
            txtQuan.Clear();

            txtTotal.Clear();

            txtPrice.Clear();
        }
        public void enableButton(bool b)
        {
            btAdd.Enabled = b;

            btCancel.Enabled = b;

            btDelete.Enabled = b;

            btSave.Enabled = b;

            btSend.Enabled = b;
        }

        private void cbPName_SelectionChangeCommitted(object sender, EventArgs e)
        {
            Item = new BUS_Item(null, cbPName.Text, null);

            displayIDItem();
        }

        private void btReview_Click(object sender, EventArgs e)
        {
            if (cbIDItem.Text == "")
            {
                MessageBox.Show("Please choose Item");

                return;
            }

            Info = new BUS_ReceiptInfo(null, cbIDItem.Text , null, 0, 0, 0);

            grd3.DataSource = Info.reviewPrice();

            grd3.Columns[0].DefaultCellStyle.Format = "dd/MM/yyyy";

            grd3.Columns[0].Width = 80;

        }

        private void btAdd_Click(object sender, EventArgs e)
        {
            btSend.Enabled = false;

            string OID = txtOID.Text;

            string InfoID= OInfo.createID();

            string Date = date.Value.ToString("yyyy/MM/dd");

            string User = txtUser.Text;

            string Status = cbStt.Text;

            string Payment = cbPay.Text;

            string Cus = cbCus.SelectedValue.ToString();

            Order = new BUS_Order(OID, null, null, null, null, null, 0);

            if(Status != "" && Payment != "" && Cus != "")
            {
                if (!Order.checkOrder())
                {
                    BUS_Order Order = new BUS_Order(OID, Date, User, Cus, Status, Payment, 0);

                    Order.addQuery();

                    //check Total = null

                    Order.updateTotal();

                    if (Order.TotalEmpty())
                    {
                        Order = new BUS_Order(OID, Date, User, Cus, Status, Payment, 0);

                        Order.updateQuery();
                    }
                }
            }

            string PID = cbIDItem.Text;

            string Quantity = txtQuan.Text;

            string PName = cbPName.Text;

            string Price = txtPrice.Text;

            string Total = txtTotal.Text;

            if (PID != "" && Quantity != "" && PName != "" && Price != "" && Total != "")
            {
                OInfo = new BUS_OrderInfo(InfoID, PID, OID, Int32.Parse(Quantity), float.Parse(Price), float.Parse(Total));

                OInfo.addQuery();

                Order = new BUS_Order(OID, Date, User, Cus, Status, Payment, 0);

                Order.updateQuery();

                Order.updateTotal();

                //check Total = null

                clearText();

                showGrd1();

                showGrd2();
            }
            else
            {
                MessageBox.Show("Please complete all information");
            }
            showGrd1();

            showGrd2();
        }

        private void grd1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                txtOID.Text = grd1.CurrentRow.Cells[0].Value.ToString();

                showGrd2();

                clearText();

                enableButton(false);

                btAdd.Enabled = true;

                btDelete.Enabled = true;

                btSend.Enabled = true;

                date.Enabled = true;

                cbStt.Enabled = true;

                cbPay.Enabled = true;

                cbCus.Enabled = true;

                flag = "OrderClick";

                date.Text = grd1.CurrentRow.Cells[1].Value.ToString();

                cbStt.Text = grd1.CurrentRow.Cells[4].Value.ToString();

                cbPay.Text = grd1.CurrentRow.Cells[5].Value.ToString();

                cbCus.SelectedValue = grd1.CurrentRow.Cells[3].Value.ToString();

            }
        }

        private void btCancel_Click(object sender, EventArgs e)
        {
            Form_Load();
        }

        private void btNew_Click(object sender, EventArgs e)
        {
            Form_Load();

        }

        private void btSave_Click(object sender, EventArgs e)
        {
            string OID = txtOID.Text;

            string Date = date.Value.ToString("yyyy/MM/dd");

            string User = txtUser.Text;

            string Status = cbStt.Text;

            string Payment = cbPay.Text;

            string PID = cbIDItem.Text;

            string Quantity = txtQuan.Text;

            string PName = cbPName.Text;

            string Price = txtPrice.Text;

            string Total = txtTotal.Text;

            string Cus = cbCus.SelectedValue.ToString();

            if (flag.Equals("InfoClick"))
            {
                if (PID != "" && Quantity != "" && PName != "" && Price != "" && Total != "")
                {
                    OInfo = new BUS_OrderInfo(grd2.CurrentRow.Cells[0].Value.ToString(), PID, OID, Int32.Parse(Quantity), float.Parse(Price), float.Parse(Total));

                    OInfo.updateQuery();

                    Order = new BUS_Order(OID, Date, User, Cus, Status, Payment, 0);

                    Order.updateTotal();

                    clearText();

                    showGrd1();

                    showGrd2();

                    groupBox2.Enabled = true;

                }
                else
                {
                    MessageBox.Show("Please complete all information");
                }
            }
            else if (flag.Equals("DateChange") || flag.Equals("SttChange") || flag.Equals("PaymentChange") || flag.Equals("CustomerChange"))
            {

                Order = new BUS_Order(grd1.CurrentRow.Cells[0].Value.ToString(), Date, User, Cus, Status, Payment, 0);

                Order.updateQuery();

                Order.updateTotal();

                clearText();

                showGrd1();

                showGrd2();

                groupBox2.Enabled = true;

                btSave.Enabled = false;

            }

        }

        private void txtPrice_TextChanged_1(object sender, EventArgs e)
        {
            if (txtQuan.Text == "" || txtPrice.Text == "")
            {
                txtTotal.Text = "0";

                return;
            }
            int Total = Int32.Parse(txtQuan.Text) * Int32.Parse(txtPrice.Text);

            txtTotal.Text = Total.ToString();
        }

        private void txtQuan_TextChanged(object sender, EventArgs e)
        {
      
            if (txtQuan.Text == "" || txtPrice.Text == "")
            {
                 txtTotal.Text = "0";

                return;
            }
            int Total = Int32.Parse(txtQuan.Text) * Int32.Parse(txtPrice.Text);

            txtTotal.Text = Total.ToString();
        }

        private void txtQuan_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void txtPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }



        private void btDelete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you want to delete?", "", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                if (flag.Equals("InfoClick"))
                {
                    OInfo = new BUS_OrderInfo(grd2.CurrentRow.Cells[0].Value.ToString(), null, null, 0, 0, 0);

                    OInfo.deleteQuery();

                    BUS_Order Order = new BUS_Order(txtOID.Text, null, null, null, null, null , 0);

                    Order.updateTotal();

                    //check Total = null

                    string OID = txtOID.Text;

                    //string Date = date.Text.ToString();
                    string Date = date.Value.ToString("yyyy/MM/dd");

                    string User = txtUser.Text;

                    string Status = cbStt.Text;

                    string Pay = cbPay.Text;

                    string Cus = cbCus.SelectedValue.ToString();

                    if (Order.TotalEmpty())
                    {
                        Order = new BUS_Order(OID, Date, User, Cus, Status, Pay, 0);

                        Order.updateQuery();
                    }

                    Form_Load();
                }
                else if (flag.Equals("OrderClick"))
                {
                    Order = new BUS_Order(grd1.CurrentRow.Cells[0].Value.ToString(), null, null, null, null, null, 0);

                    /*if (Receipt.checkOrderInfo())
                    {
                        MessageBox.Show("Cannot delete this Receipt because the item has been sold");
                        return;
                    }*/

                    Order.deleteQuery();

                    Form_Load();
                }
            }
        }

        public void ExportFile(DataTable dataTable, string sheetName, string title)
        {
            //Tạo các đối tượng Excel

            Microsoft.Office.Interop.Excel.Application oExcel = new Microsoft.Office.Interop.Excel.Application();

            Microsoft.Office.Interop.Excel.Workbooks oBooks;

            Microsoft.Office.Interop.Excel.Sheets oSheets;

            Microsoft.Office.Interop.Excel.Workbook oBook;

            Microsoft.Office.Interop.Excel.Worksheet oSheet;

            //Tạo mới một Excel WorkBook 

            oExcel.Visible = true;

            oExcel.DisplayAlerts = false;

            oExcel.Application.SheetsInNewWorkbook = 1;

            oBooks = oExcel.Workbooks;

            oBook = (Microsoft.Office.Interop.Excel.Workbook)(oExcel.Workbooks.Add(Type.Missing));

            oSheets = oBook.Worksheets;

            oSheet = (Microsoft.Office.Interop.Excel.Worksheet)oSheets.get_Item(1);

            oSheet.Name = sheetName;

            // Tạo phần Tiêu đề
            Microsoft.Office.Interop.Excel.Range head = oSheet.get_Range("A1", "D1");

            head.MergeCells = true;

            head.Value2 = title;

            head.Font.Bold = true;

            head.Font.Name = "Times New Roman";

            head.Font.Size = "20";

            head.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;

            // Tạo tiêu đề cột 

            Microsoft.Office.Interop.Excel.Range cl1 = oSheet.get_Range("A3", "A3");

            cl1.Value2 = "ID Moblie Phone";

            cl1.ColumnWidth = 12;

            Microsoft.Office.Interop.Excel.Range cl2 = oSheet.get_Range("B3", "B3");

            cl2.Value2 = "Quantity";

            cl2.ColumnWidth = 25.0;

            Microsoft.Office.Interop.Excel.Range cl3 = oSheet.get_Range("C3", "C3");

            cl3.Value2 = "Price/Item";
            cl3.ColumnWidth = 12.0;

            Microsoft.Office.Interop.Excel.Range cl4 = oSheet.get_Range("D3", "D3");

            cl4.Value2 = "Total";

            cl4.ColumnWidth = 10.5;

            Microsoft.Office.Interop.Excel.Range rowHead = oSheet.get_Range("A3", "D3");

            rowHead.Font.Bold = true;

            // Kẻ viền

            rowHead.Borders.LineStyle = Microsoft.Office.Interop.Excel.Constants.xlSolid;

            // Thiết lập màu nền

            rowHead.Interior.ColorIndex = 6;

            rowHead.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;

            // Tạo mảng theo datatable

            object[,] arr = new object[dataTable.Rows.Count, dataTable.Columns.Count];

            //Chuyển dữ liệu từ DataTable vào mảng đối tượng

            for (int row = 0; row < dataTable.Rows.Count; row++)
            {
                DataRow dataRow = dataTable.Rows[row];

                for (int col = 0; col < dataTable.Columns.Count; col++)
                {
                    arr[row, col] = dataRow[col];
                }
            }

            //Thiết lập vùng điền dữ liệu

            int rowStart = 4;

            int columnStart = 1;

            int rowEnd = rowStart + dataTable.Rows.Count - 1;

            int columnEnd = dataTable.Columns.Count;

            // Ô bắt đầu điền dữ liệu

            Microsoft.Office.Interop.Excel.Range c1 = (Microsoft.Office.Interop.Excel.Range)oSheet.Cells[rowStart, columnStart];

            // Ô kết thúc điền dữ liệu

            Microsoft.Office.Interop.Excel.Range c2 = (Microsoft.Office.Interop.Excel.Range)oSheet.Cells[rowEnd, columnEnd];

            // Lấy về vùng điền dữ liệu

            Microsoft.Office.Interop.Excel.Range range = oSheet.get_Range(c1, c2);

            //Điền dữ liệu vào vùng đã thiết lập

            range.Value2 = arr;

            // Kẻ viền

            range.Borders.LineStyle = Microsoft.Office.Interop.Excel.Constants.xlSolid;

            // Căn giữa cột mã nhân viên

            //Microsoft.Office.Interop.Excel.Range c3 = (Microsoft.Office.Interop.Excel.Range)oSheet.Cells[rowEnd, columnStart];

            //Microsoft.Office.Interop.Excel.Range c4 = oSheet.get_Range(c1, c3);

            //Căn giữa cả bảng 
            oSheet.get_Range(c1, c2).HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
        }
        private void btPrint_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();

            DataColumn col2 = new DataColumn("IDItem");

            DataColumn col4 = new DataColumn("Quantity");

            DataColumn col5 = new DataColumn("Price");

            DataColumn col6 = new DataColumn("Total");

            dt.Columns.Add(col2);
            dt.Columns.Add(col4);
            dt.Columns.Add(col5);
            dt.Columns.Add(col6);

            foreach(DataGridViewRow dtgvrow in grd2.Rows) 
            {
                DataRow dtrow = dt.NewRow();

                dtrow[0] = dtgvrow.Cells[1].Value;
                dtrow[1] = dtgvrow.Cells[3].Value;
                dtrow[2] = dtgvrow.Cells[4].Value;
                dtrow[3] = dtgvrow.Cells[5].Value;

                dt.Rows.Add(dtrow);
            }
            ExportFile(dt, "Sheet01", "Order");

        }

        private void grd2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                cbIDItem.Text = grd2.CurrentRow.Cells[1].Value.ToString();

                txtPrice.Text = grd2.CurrentRow.Cells[5].Value.ToString();

                txtQuan.Text = grd2.CurrentRow.Cells[4].Value.ToString();

                enableButton(true);

                groupBox2.Enabled = true;

                btAdd.Enabled = false;

                btSend.Enabled = false;

                date.Enabled = false;

                cbStt.Enabled = false;

                cbCus.Enabled = false;

                cbPay.Enabled = false;

                cbIDItem.SelectedValue = grd2.CurrentRow.Cells[1].Value.ToString();

                flag = "InfoClick";
            }
        }

        private void cbStt_Click(object sender, EventArgs e)
        {

        }

        private void cbCus_Click(object sender, EventArgs e)
        {

        }

        private void cbPay_Click(object sender, EventArgs e)
        {

        }

        private void date_CloseUp(object sender, EventArgs e)
        {
            enableButton(false);

            btSave.Enabled = true;

            btAdd.Enabled = true;

            btDelete.Enabled = true;

            flag = "DateChange";

            groupBox2.Enabled = true;
        }

        private void date_ValueChanged(object sender, EventArgs e)
        {
            enableButton(false);

            btSave.Enabled = true;

            btAdd.Enabled = true;

            btDelete.Enabled = true;

            flag = "CustomerChange";

            groupBox2.Enabled = true;
        }

        private void cbPay_SelectedIndexChanged(object sender, EventArgs e)
        {
            enableButton(false);

            btSave.Enabled = true;

            btAdd.Enabled = true;

            btDelete.Enabled = true;

            flag = "PaymentChange";

            groupBox2.Enabled = true;
        }

        private void cbStt_SelectedIndexChanged(object sender, EventArgs e)
        {
            enableButton(false);

            btSave.Enabled = true;

            btAdd.Enabled = true;

            btDelete.Enabled = true;

            flag = "SttChange";

            groupBox2.Enabled = true;
        }
        private void cbCus_SelectedIndexChanged(object sender, EventArgs e)
        {
            enableButton(false);

            btSave.Enabled = true;

            btAdd.Enabled = true;

            btDelete.Enabled = true;

            flag = "CustomerChange";

            groupBox2.Enabled = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Customer = new BUS_Customer(cbCus.SelectedValue.ToString(), null, null, null, null, null);

            string Email = Customer.getEmail();

            string content = "Please complete the payment. I will check and update your status bill";

            fEmail form1 = new fEmail(Email, content);

            this.Hide();

            form1.ShowDialog();

            this.Show();
        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }
    }
}
