﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;

namespace BUS
{
    public class BUS_Inventory
    {
        DAL_Inventory Inventory;

        public BUS_Inventory(string DateStart, string DateEnd, string IDItem, int Order, int Receipt, int inventory)
        {
            Inventory = new DAL_Inventory(DateStart, DateEnd, IDItem, Order, Receipt, inventory);
        }

        public DataTable selectInventory()
        {
            return Inventory.SelectInventory_Detail();
        }
        public int getOrder()
        {
            DataTable tb = Inventory.SelectInventory();

            return Int32.Parse(tb.Rows[0][1].ToString());
        }
        public int getReceipt()
        {
            if (Inventory.SelectInventory().Rows.Count <= 0)
            {
                return 0;
            }
            DataTable tb = Inventory.SelectInventory();

            return Int32.Parse(tb.Rows[0][0].ToString());
        }
        public int getInventory()
        {
            if (Inventory.SelectInventory().Rows.Count <= 0)
            {
                return 0;
            }
            DataTable tb = Inventory.SelectInventory();

            return Int32.Parse(tb.Rows[0][2].ToString());
        }
        public int getOrderbyDate()
        {
            if (Inventory.SelectInventoryByDate().Rows.Count <= 0)
            {
                return 0;
            }
            DataTable tb = Inventory.SelectInventoryByDate();

            return Int32.Parse(tb.Rows[0][1].ToString());
        }
        public int getReceiptbyDate()
        {
            if (Inventory.SelectInventoryByDate().Rows.Count <= 0)
            {
                return 0;
            }
            DataTable tb = Inventory.SelectInventoryByDate();

            return Int32.Parse(tb.Rows[0][0].ToString());
        }
        public int getInventorybyDate()
        {
            if (Inventory.SelectInventoryByDate().Rows.Count <= 0)
            {
                return 0;
            }
            DataTable tb = Inventory.SelectInventoryByDate();

            return Int32.Parse(tb.Rows[0][2].ToString());
        }
        public DataTable selectInventorybyDate()
        {
            return Inventory.SelectInventory_DetailsByDate();
        }
        public string getNameTop1()
        {
            if (Inventory.SelectTop3().Rows.Count <= 0)
            {
                return "";
            }
            DataTable tb = Inventory.SelectTop3();

            return (tb.Rows[0][0].ToString());
        }
        public string getNameTop2()
        {
            if (Inventory.SelectTop3().Rows.Count <= 0)
            {
                return "";
            }
            DataTable tb = Inventory.SelectTop3();

            return (tb.Rows[1][0].ToString());
        }
        public string getNameTop3()
        {
            if (Inventory.SelectTop3().Rows.Count <= 0)
            {
                return "";
            }
            DataTable tb = Inventory.SelectTop3();

            return (tb.Rows[2][0].ToString());
        }
        public string getOrderTop1()
        {
            if (Inventory.SelectTop3().Rows.Count <= 0)
            {
                return "";
            }
            DataTable tb = Inventory.SelectTop3();

            return (tb.Rows[0][1].ToString());
        }
        public string getOrderTop2()
        {
            if (Inventory.SelectTop3().Rows.Count <= 0)
            {
                return "";
            }
            DataTable tb = Inventory.SelectTop3();

            return (tb.Rows[1][1].ToString());
        }
        public string getOrderTop3()
        {
            if (Inventory.SelectTop3().Rows.Count <= 0)
            {
                return "";
            }
            DataTable tb = Inventory.SelectTop3();

            return (tb.Rows[2][1].ToString());
        }
        public string getNameTop1byDate()
        {
            if (Inventory.SelectTop3().Rows.Count <= 0)
            {
                return "";
            }
            DataTable tb = Inventory.SelectTop3byDate();

            return (tb.Rows[0][0].ToString());
        }
        public string getNameTop2byDate()
        {   
            if (Inventory.SelectTop3byDate().Rows.Count <= 0)
            {
                return "";
            }
            DataTable tb = Inventory.SelectTop3byDate();

            return (tb.Rows[1][0].ToString());
        }
        public string getNameTop3byDate()
        {
            if (Inventory.SelectTop3byDate().Rows.Count <= 0)
            {
                return "";
            }
            DataTable tb = Inventory.SelectTop3byDate();

            return (tb.Rows[2][0].ToString());
        }
        public string getOrderTop1byDate()
        {
            if (Inventory.SelectTop3byDate().Rows.Count <= 0)
            {
                return "";
            }
            DataTable tb = Inventory.SelectTop3byDate();

            return (tb.Rows[0][1].ToString());
        }
        public string getOrderTop2byDate()
        {
            if (Inventory.SelectTop3byDate().Rows.Count <= 0)
            {
                return "";
            }
            DataTable tb = Inventory.SelectTop3byDate();

            return (tb.Rows[1][1].ToString());
        }
        public string getOrderTop3byDate()
        {
            if (Inventory.SelectTop3byDate().Rows.Count <= 0)
            {
                return "";
            }
            DataTable tb = Inventory.SelectTop3byDate();

            return (tb.Rows[2][1].ToString());
        }
    }
}
