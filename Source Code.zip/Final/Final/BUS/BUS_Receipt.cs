﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;

namespace BUS
{
    public class BUS_Receipt
    {
        DAL_Receipt Receipt;

        public BUS_Receipt(string ID, string DateReceipt, float Total, string Status, string UserID)
        {
            Receipt = new DAL_Receipt(ID, DateReceipt,Total, Status, UserID);
        }

        public void addQuery()
        {
            Receipt.addQuery();
        }
        public void updateQuery()
        {
            Receipt.updateQuery();
        }
        public void deleteQuery()
        {
            Receipt.deleteQuery();
        }
        public DataTable selectQuery()
        {
            return Receipt.selectQuery();
        }
        public string CreateID()
        {
            DataTable tb = Receipt.getReceiptDesc(); //R00001
            if (tb.Rows.Count > 0)
            {
                string res = tb.Rows[0][0].ToString();
                int stt = int.Parse(res.Substring(1, 5)) + 1;
                if (stt < 10)
                    res = "R0000" + stt.ToString();
                else if (stt < 100)
                    res = "R000" + stt.ToString();
                else if (stt < 1000)
                    res = "R00" + stt.ToString();
                else if (stt < 10000)
                    res = "R0" + stt.ToString();
                return res;
            }
            else
            {
                return "R00001";
            }
        }
        public bool checkReceipt()
        {
            return Receipt.checkReceipt().Rows.Count > 0;
        }
        public bool checkOrderInfo ()
        {
            return Receipt.checkOrderInfo().Rows.Count > 0;
        }
        public void updateTotal()
        {
            Receipt.updateTotal();
        }
        public bool TotalEmpty()
        {
            if (Receipt.TotalEmpty().Rows.Count > 0) 
            {
                return false;
            }
            return true;
        }
    }
}
