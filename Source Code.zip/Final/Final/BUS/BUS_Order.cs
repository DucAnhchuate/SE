﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;

namespace BUS
{
    public class BUS_Order
    {
        DAL_Order Order;

        public BUS_Order(string ID, string DateOrder, string UserID, string Customer, string Status, string Payment, float Total)
        {
            Order = new DAL_Order(ID, DateOrder, UserID, Customer, Status, Payment, Total);
        }

        public void addQuery()
        {
            Order.addQuery();
        }
        public void updateQuery()
        {
            Order.updateQuery();
        }
        public void deleteQuery()
        {
            Order.deleteQuery();
        }
        public DataTable selectQuery()
        {
            return Order.selectQuery();
        }
        public string CreateID()
        {
            DataTable tb = Order.getOrderDesc(); //Order00001
            if (tb.Rows.Count > 0)
            {
                string res = tb.Rows[0][0].ToString();
                int stt = int.Parse(res.Substring(5, 5)) + 1;
                if (stt < 10)
                    res = "Order0000" + stt.ToString();
                else if (stt < 100)
                    res = "Order000" + stt.ToString();
                else if (stt < 1000)
                    res = "Order00" + stt.ToString();
                else if (stt < 10000)
                    res = "Order0" + stt.ToString();
                return res;
            }
            else
            {
                return "Order00001";
            }
        }
        public bool checkOrder()
        {
            return Order.checkOrder().Rows.Count > 0;
        }
        public void updateTotal()
        {
            Order.updateTotal();
        }
        public bool TotalEmpty()
        {
            if (Order.CheckTotalPrice().Rows.Count > 0)
            {
                return false;
            }
            return true;
        }
    }
}
