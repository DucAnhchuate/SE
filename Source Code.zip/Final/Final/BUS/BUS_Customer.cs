﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;

namespace BUS
{
    public class BUS_Customer
    {
        DAL_Customer Customer;

        public BUS_Customer(string ID, string DisplayName, string Address, string Phone, string Email, string MoreInfo)
        {
            Customer = new DAL_Customer(ID, DisplayName, Address, Phone, Email, MoreInfo);
        }

        public void addQuery()
        {
            Customer.addQuery();
        }
        public void updateQuery()
        {
            Customer.updateQuery();
        }
        public void deleteQuery()
        {
            Customer.deleteQuery();
        }
        public DataTable selectQuery()
        {
            return Customer.selectQuery();
        }
        public string CreateID()
        {
            DataTable tb = Customer.getCustomerDesc(); 
            if (tb.Rows.Count > 0)
            {
                string res = tb.Rows[0][0].ToString();
                int stt = int.Parse(res.Substring(3, 2)) + 1;
                if (stt < 10)
                    res = "Cus0" + stt.ToString();
                else if (stt < 100)
                    res = "Cus" + stt.ToString();
                return res;
            }
            else
            {
                return "Cus01";
            }
        }
        public string getID()
        {
            return Customer.getID().Rows[0][0].ToString();
        }
        public string getEmail()
        {
            return Customer.getEmail().Rows[0][0].ToString();
        }
        public bool checkPhone()
        {
            if (Customer.checkPhone().Rows.Count > 0) 
            {
                return true;
            }
            return false;
        }
    }
}
