﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;

namespace BUS
{
    public class BUS_Item
    {
        DAL_Item Item;

        public BUS_Item(string ID, string DisplayName, string Supplier)
        {
            Item = new DAL_Item(ID, DisplayName, Supplier);
        }

        public void addQuery()
        {
            Item.addQuery();
        }
        public void updateQuery()
        {
            Item.updateQuery();
        }
        public void deleteQuery()
        {
            Item.deleteQuery();
        }
        public DataTable selectQuery()
        {
            return Item.selectQuery();
        }
        public DataTable selectQuery1()
        {
            return Item.selectQuery1();
        }
        public string CreateID()
        {
            DataTable tb = Item.getItemDesc(); //Item01
            if (tb.Rows.Count > 0)
            {
                string res = tb.Rows[0][0].ToString();
                int stt = int.Parse(res.Substring(4, 2)) + 1;
                if (stt < 10)
                    res = "Item0" + stt.ToString();
                else
                    res = "Item" + stt.ToString();
                return res;
            }
            else
            {
                return "Item01";
            }
        }
        public string getIDbySandD()
        {
            if (Item.getIDbySandD().Rows.Count > 0)
            {
                return Item.getIDbySandD().Rows[0][0].ToString();

            }
            else 
            {
                return null; 
            }
        }
        public DataTable getIDbyD()
        {
            if (Item.getIDbyD().Rows.Count > 0)
            {
                return Item.getIDbyD();

            }
            else
            {
                return null;
            }
        }
    }
}
