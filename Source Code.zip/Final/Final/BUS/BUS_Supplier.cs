﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;

namespace BUS
{
    public class BUS_Supplier
    {
        DAL_Supplier Supplier;

        public BUS_Supplier(string ID, string DisplayName, string Address, string Phone, string Email, string MoreInfo)
        {
            Supplier = new DAL_Supplier(ID, DisplayName, Address, Phone, Email, MoreInfo);
        }

        public void addQuery()
        {
            Supplier.addQuery();
        }
        public void updateQuery()
        {
            Supplier.updateQuery();
        }
        public void deleteQuery()
        {
            Supplier.deleteQuery();
        }
        public DataTable selectQuery()
        {
            return Supplier.selectQuery();
        }
        public string CreateID()
        {
            DataTable tb = Supplier.getSupplierDesc(); //Sup01
            if (tb.Rows.Count > 0)
            {
                string res = tb.Rows[0][0].ToString();
                int stt = int.Parse(res.Substring(3, 2)) + 1;
                if (stt < 10)
                    res = "Sup0" + stt.ToString();
                else if (stt < 100)
                    res = "Sup" + stt.ToString();
                return res;
            }
            else
            {
                return "Sup01";
            }
        }
        public string getID()
        {
            return Supplier.getID().Rows[0][0].ToString();
        }
        public string getName()
        {
            return Supplier.getName().Rows[0][0].ToString();
        }
        public bool checkName()
        {
            if (Supplier.checkName().Rows.Count > 0)
            {
                return true;
            }
            return false;
        }
    }
}

