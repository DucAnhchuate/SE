﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;

namespace BUS
{
    public class BUS_Revenue
    {   
        DAL_Revenue Revenue = new DAL_Revenue();
        public BUS_Revenue() { }
        public DataTable getRevenue()
        {
            return Revenue.getRevenue();
        }
        public string getBest()
        {
            if (Revenue.getBest().Rows.Count > 0)
            {
                return Revenue.getBest().Rows[0][0].ToString();

            }
            return null;
        }
    }
}
