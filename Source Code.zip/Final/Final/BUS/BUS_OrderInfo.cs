﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;

namespace BUS
{
    public class BUS_OrderInfo
    {
        DAL_OrderInfo OrderInfo;

        public BUS_OrderInfo(string ID, string IDItem , string IDOrder, int Quantity, float Price, float Total)
        {
            OrderInfo = new DAL_OrderInfo(ID, IDItem, IDOrder, Quantity, Price, Total);
        }

        public void addQuery()
        {
            OrderInfo.addQuery();
        }
        public void updateQuery()
        {
            OrderInfo.updateQuery();
        }
        public void deleteQuery()
        {
            OrderInfo.deleteQuery();
        }
        public DataTable selectQuery()
        {
            return OrderInfo.selectQuery();
        }
        public string createID()
        {
            DataTable tb = OrderInfo.getOrderInfoDesc(); //OI00001
            if (tb.Rows.Count > 0)
            {
                string res = tb.Rows[0][0].ToString();
                int stt = int.Parse(res.Substring(2, 5)) + 1;
                if (stt < 10)
                    res = "OI0000" + stt.ToString();
                else if (stt < 100)
                    res = "OI000" + stt.ToString();
                else if (stt < 1000)
                    res = "OI00" + stt.ToString();
                else if (stt < 10000)
                    res = "OI0" + stt.ToString();
                return res;
            }
            else
            {
                return "OI00001";
            }
        }

    }
}
