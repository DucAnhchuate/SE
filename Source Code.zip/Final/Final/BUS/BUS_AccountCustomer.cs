﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;

namespace BUS
{
    public class BUS_AccountCustomer
    {
        DAL_AccountCustomer Account;

        public BUS_AccountCustomer(string Username, string Password, string isActive)
        {
           Account = new DAL_AccountCustomer(Username, Password, isActive);
        }
        public void addQuery()
        {
            Account.addQuery();
        }
        public void deleteQuery()
        {
            Account.deleteQuery();
        }
        public void updateStt()
        {
            Account.updateStt();
        }
        public DataTable selectQuery()
        {
            return Account.selectQuery();
        }
    }
}
